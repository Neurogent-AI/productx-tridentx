**PLATFORMX MVP Kickoff with Neurogent-20260615\_165951UTC-Meeting Recording**

June 15, 2026, 4:59PM

35m 16s

**Jang Singh**   0:24  
Hey, Kajal.

**Kajal Yadav**   0:30  
Hello, sir. Good morning.

**Jang Singh**   0:32  
Morning.  
Atul.  
Uh...  
Meeting.

**Kajal Yadav**   0:41  
Yeah, we have, yeah.  
Please, are listening.

**Jang Singh**   0:46  
Uh.  
Field service, right?

**Kajal Yadav**   0:51  
Yeah, and uh, on 17th.

**Jang Singh**   0:51  
And.  
Something. Okay.

**Kajal Yadav**   1:01  
Yeah.

**Jang Singh**   1:01  
1670\.

**Kajal Yadav**   1:03  
Yeah.

**Jang Singh**   1:05  
Because it's coming.  
Hey, good morning, Prakash.

**Vikas Ranga**   1:17  
Finding, come on.

**Jang Singh**   1:19  
How are you?

**Vikas Ranga**   1:20  
How are you doing? How are you doing? All good, sir. How are you?

**Jang Singh**   1:23  
Good, great, great, though.  
I think the jumping right now, there was no other call, so...  
Shruti here, Kajal here.  
With us coming and Anand.

**Vikas Ranga**   1:39  
Sounds good, sounds good, you Shruti.

**Shruti Sathe**   1:39  
I Vikas.

**Kajal Yadav**   1:44  
Play Vikas song.

**Jang Singh**   1:45  
Yeah.

**Vikas Ranga**   1:46  
Hey, Kajal.  
How are you?

**Kajal Yadav**   1:52  
Yeah, I'm good.

**Gurtaj Alag**   2:00  
Give me a second.

**Jang Singh**   2:10  
Yeah.

**Shruti Sathe**   2:11  
Give me.

**Jang Singh**   2:12  
Mm.

**Shruti Sathe**   2:15  
Kajal is Satyajeet going to join? Oh, I see. He is here. OK.

**Gurtaj Alag**   2:30  
Give me one second, one second.

**Jang Singh**   2:33  
Okay.

**Vikas Ranga**   2:54  
Yeah.  
Yes.

**Shruti Sathe**   3:02  
I think we can start, right?

**Vikas Ranga**   3:04  
I.  
Yeah, let's start it up, so...  
Let me share my screen. Like, you know, this this call was mainly to to review the your UX and freeze it up, and then we can like, you know, go ahead, so they there are few few things that we need and that can to get going development to well and we'll share that up as well.  
So maybe let me share my screen and show the UI UX.  
So, you can see my screen.  
S.

**Jang Singh**   3:54  
Yes.

**Vikas Ranga**   3:55  
Okay, sounds good. So showing it up, let me start from the journey first. So then...  
So, as we know, know that the first point will be the data of of of.  
Marketplace, so this will be the one screen here.

**Shruti Sathe**   4:17  
Hold on, let me see. Gurtaj, are you there or? I'll just, it will be good if he, yeah, okay. You're on mute.

**Gurtaj Alag**   4:28  
Yeah, I'm actually, you know, going for a meeting. That's why, like, you know, I'm taking this phone like on my, what do you call on my phone? You know, I like what you showed one thought because I'll be in the car and then I'll keep on listening to, you know, basically what you're showing Vikas.  
Because I, one thing dawned on me and maybe that is the new way I spoke with many people. I've got really some smart people who work Microsoft, Meta, Google, and over the weekend I've been speaking with them just to, and I'm sure that you're aware about it. You know, when...  
There is a data, you know, they're saying that create an agent for that, you know, like a marketing agent. There's an engineering agent. In the engineering agent, there is a RF design agent, RF opto agent, maybe, or there's only one engineering agent. And there is a customer agent, there is a, and then there are skills that you give.  
Train these agents like reactive, you know, your proactive, your threshold, your visualization, your diagnostic. In the diagnostic, there'll be a master agent. It is able to assign tasks to this multiple agents, like, okay.  
Correlate work with all these four agents and tell me like, OK, the market share went low because the network performance is bad as an example, because these are two different agents and then the last part last two being the prescriptive and sorry, your predictive and prescriptive. I just again, this is maybe a very lame way of sharing, but I just.  
I want to share the thoughts that I'm able to understand, which will make our architecture very robust, very future ready, because there is an agent you are just training different skills. Maybe that is the way it is. I mean, for me, like you know, for me all this is new, but I'm also learning very quickly.  
Does this make sense what they're suggesting or is this the wrong view of approaching it?

**Vikas Ranga**   6:35  
No, but that's the world going towards, and like, you know, on a high high level when you see it up, what's the main value adds? The main value add is that there's a workflow, and that workflow needs to be.

**Gurtaj Alag**   6:40  
Yeah.

**Vikas Ranga**   6:53  
Auto, ohh, weighted and then that workflow can have various task to to be done. So then there will be one agent for one like you know task and if there are 10 tasks to be done, one agent can be like you know.  
Uh, the like, like, like a planner who will plan all the tasks, then if if that one will plan 4 tasks, then each one will be doing those four tasks, and lastly, there will be one QA.  
Agent as well, who will cure the final, like, you know, result and so and and and when we say the high level value add, when say for this workflow, if there are 20 folks who are doing this job now, if this workflow will be.  
Auto vetted, then we don't need the full, like, you know, 24, we'll just need four or five under there.

**Gurtaj Alag**   8:01  
So, so one question, because and this just, I mean, you know, like I think that this is all very, very good. So, you would say, rather than having a marketing or an engineering agent and then assigning them tasks, it is the other way around. You, you basically have an area, say marketing, which has multiple tasks in it.

**Vikas Ranga**   8:04  
Yes.

**Gurtaj Alag**   8:20  
And each of those tasks is being done by an agent.  
Uh...

**Vikas Ranga**   8:24  
Yeah, yeah, yeah.

**Gurtaj Alag**   8:25  
That's OK, so you don't you don't create a I got the part, so there's an area marketing and then there are multiple agents based from the task that you are assigning that agent.

**Vikas Ranga**   8:31  
Ch.  
Yeah, yeah, yeah.

**Gurtaj Alag**   8:39  
What are the drawback to the other approach? You know, like, you know, you have a marketing agent and then you're teaching them skills like reactive, proactive, prescriptive, diagnostic, that kind of thing. I think, I think I'm...

**Vikas Ranga**   8:44  
I.  
So, in in in in my view, the skills like a reactive, like a proactive and, so we should not generalize.  
All the work that that should fit fit in this uh five steps only means like those five steps can be our one framework and then we can see it up what will fall in this one like you know framework only. What do I see it like you know being?  
AI, the one liner when I see all use cases will pertain is that one, whether we can save cost for client or not, and then saving cost will come up.

**Gurtaj Alag**   10:05  
Yeah.

**Vikas Ranga**   10:05  
But what do I let the way I am seeing it, that that needs to be the base to think, and then from that on we can define how we will build what we will build, where our one framework can be like, you know, what you are shared, Daryl.  
The not speak, uh, uh, productive and so and so forth. That can be a one framework. We can see it up where we can use it, but we should not.  
Always think like that framework will like call.  
Fit for all.

**Gurtaj Alag**   10:45  
Okay, I got the point. So basically, any one double click, I mean just theoretically say, let's say engineering and then engineering has got, you know, like you can look at that there is some KPIs drop call rate throughput, simple.  
And there is maybe some alarms now when you say.  
Workflow.  
Agent tasks. Can you explain in this scenario, engineering is the category, and then there are subcategories like a network KPI and then alarm. Now, just give me an example of where the agents will come. The agent is for a workflow automation, basically, yeah.

**Vikas Ranga**   11:27  
Okay.  
Yeah, so then there, what do we need to see it up in each department? There are folks who are doing some job. So then we have to see it up. If to get a job done, if they are doing 20 tasks and we feel that, hey, 10 tasks, we can.  
Automate like when we see the job of.  
Autos.  
Engineer, so what they are seeing is that they are seeing that data of, like, you know, network and like on towers and just seeing that data, where do we have poor, like, like, like, like, you know, signals and where it is good and.

**Gurtaj Alag**   11:58  
Mhm.

**Vikas Ranga**   12:15  
Then one thing is that they are the reviewing their data and dashboard both, and there can be one thing can be there if the data will be lower than a certain like, like in a threshold, then.  
alarm will be shown. That will be the one case, but that can be a rule-based only. But \#2 can be when they are reviewing the dashboard and the data, then they might be taking some like, you know, decision.

**Gurtaj Alag**   12:39  
Yeah.

**Vikas Ranga**   12:52  
what to do. And so then that knowledge base will be there in their own mind. And then while seeing the dashboard and the data, they might take some decision and they may be doing some work. So then we need  
To see it up, yeah, yeah.

**Gurtaj Alag**   13:13  
No, no, see, I just thought it was coming in my mind that let's look at a company and I'm talking at framework level. It was very, very good conversation. I mean, it'll clear my doubts. More than likely, obviously, you...  
more than me in this area framework. So it can be like in any company, there are various departments. There is sales, there is marketing, there is engineering. Now in engineering, there are various departments, there is the headquarters, there is the field in the field.  
There is operations, there is development, deployment, there is RF.  
My question is, do you have like an agent who's like the SVP of a department? I mean, he's a super agent, marketing. And then you slice and dice, like the main guy in, you know, engineering, who I understand engineering much better than the other departments.  
He's like the CTO or the SVP, whatever, master agent, engineering. Then inside, there are departments that do different tasks.  
So, they are the...  
many agents or whatever you want to call it. So now now you have an org engineering which is run by a master super agent with multiple agents and the agents are.  
The way the trusts are clubbed in engineering, is that the way the framework works? Because I'm just trying to understand, because once I understand the framework, then I think it's going to be sweet butter.

**Vikas Ranga**   14:52  
No, no.  
Yeah, yeah, no, no, we, we, we have not, we means, as the world has not reached to that like a stage now, where each department.  
hierarchy can run by agents only where there can be one  
Agent who act as like, like a CTO, and then there are like, you know, developers for for that work we have in.  
Agent as well, so we have not reached to that stage yet, so the stage we are in is that one that each role, like you know, people will be there, there will be a CTO, there will be a like developer, there will be a QA, there will be a.

**Gurtaj Alag**   15:36  
Mhm.

**Vikas Ranga**   15:48  
Person who managing, like, you know, a...  
Product, so these will be there. The only thing that will get automated is that.  
Each of these role people are doing some work. Wherever there's a like generation work, be it generating a document or generating a code or generating a like a social media post or say anywhere there's a generation work.  
So...  
Agent will do that work, but that role.  
Hasan needs to still review it, like, say, when I see say it from development side, so...

**Gurtaj Alag**   16:32  
The.

**Vikas Ranga**   16:38  
Agent can write, like, you know, a PRD that needs to be written by, like, like, like, like a PM, but PM still needs to review it and then guide that.  
agent well to get the PRD. Same way for developer.  
Agent can write the code, but developer still needs to review that code and make sure that code is really good that we need. So then what will be the case? Like say in a company.

**Gurtaj Alag**   17:09  
It.  
Yeah.

**Vikas Ranga**   17:17  
If there are 10 developers and when they are not using.  
Agent, they all write the code now when they are using.  
Agent, when then they don't need to write the code, they just have to review the code. Then, for the same work, they don't need 10 developer, they they just need two, so then that's why what...

**Gurtaj Alag**   17:43  
Mm.

**Vikas Ranga**   17:46  
Agent is doing it cannot replace the job like a function. What these are doing is that same folk who is doing some work. Now they can do the work of say 4I.  
Like in a folks when they, they, they like, ohh, use this.

**Gurtaj Alag**   18:10  
OK, OK, Nokia, I think I'm getting, yeah, now you can share your screen, what you were showing. I'll see it on my phone, yeah.

**Vikas Ranga**   18:10  
S.  
Okay, sure, sure. So when you see it, our first step was to get the data from various like places, be it like, you know, snowflake or like packeting platform.  
UNMS, T, PIM, so and so forth. So that page is like from where do we have the data now? And when we get a new source of data, then like, you know, we can get the data as well. So this page is just showing those like, you know,  
sources only.  
Now, when we go to data layer, so we can just view that data only, like, you know, there are each department like.  
Engineering, we can see a drop call rate data or DL like like a throughput data.  
RC data and so and so forth. So on this page we are just getting that data linked to a source so that we have the data. On this page we can kind of visualize that data. So visualization can get  
Can vary as as well, this will not be like this will be a linear chart for all the data points, so but that may vary that, like, you know, maybe we can set and like.  
Define that. So these are the two. One is to get the data source, second is to visualize the data. When we have all the data, our next point that you are saying that anyone can build our use case. So say this, this can be a use case.  
Ohh.  
Builder, where, like, say, if I'll just choose this use case, or we can define a new one as well, the use case of.

**Gurtaj Alag**   20:21  
Yeah.

**Vikas Ranga**   20:28  
RF.  
Engineer. So on the next one we can choose this data like you know for this use case we want to have what data.  
and if we choose any data point next is that till what level we want to have this use case build. This can be reactive or or like a proactive or diagnostic and so on and so forth. So we can just define this level till what level we want to have this.  
per use case build. So then now how do we want to have this use case? We just want to see a dashboard only, we want to see a GIS map too, or we want to have an.  
AI agent as well to chat and we want to have like, you know, reporting too.  
Now, so this is kind of the last page where we are giving this.  
agent name as well and now going ahead, previewing the last step and then on this use case gallery we can have the old use case that's built and now if we want to see the details of this use case then we can go there where we can have kind of.  
For detail of of this use case as as as well, so it's kind of like you know, a dashboard will be shown. A dashboard can can be like like this and if I'm going going kind of in a.  
Put a tail.  
And.  
So then if say I am going on a retail then there can be a chat platform as well for this use case. So this is more like if it wants to ask which sites are underperforming.

**Gurtaj Alag**   22:14  
Yes.

**Vikas Ranga**   22:30  
Today, then our chat platform kind of can get the data. Can show the list. These are the like, you know, sites. That's the kind of rating for that. There can can be a GIS based map also for that where these are and so on and so forth.  
And let me just ask, why is it?  
Degraded.  
and can can can be like you know these are something and the but you please being is can be at added. So then here kind of a chat platform like you know when when I go back here and show you.  
Once more, it's a.  
more like was this one. So the first step was to have all the data at one place, data can be visualized, use case can be built like this, and when the use case is built, and then the use case can be viewed like this as well, there can be a change.  
Ohh.  
Platform 2, if you user has some doubts and so on and so forth, and so then for this two, if say for any use case, if it needs to be shown as a directive and press directive.

**Gurtaj Alag**   23:49  
Yes.

**Vikas Ranga**   24:03  
It can be like this, like say if there's a use case of market share.

**Gurtaj Alag**   24:04  
We.  
And.

**Vikas Ranga**   24:11  
forecast there can be a graph. This is data so far how it will be in the like in the future and yeah, so so so that that's the high high high level view basis meetings we have.

**Gurtaj Alag**   24:21  
Shh.

**Vikas Ranga**   24:31  
We had show so far what to be done.

**Gurtaj Alag**   24:39  
You know, I'll give you my comment, Vikas.

**Vikas Ranga**   24:43  
I.

**Gurtaj Alag**   24:44  
Very.  
Very impressive.  
It is, it is in the right direction, but I'll take a pause. Shruti, any thoughts?

**Shruti Sathe**   24:58  
Yeah, no, it looks really good. Yeah, I think the view that we were looking for, you know, it kind of fits that vision. So yeah, I think, yeah, very, very good. We are, I think we are on the right track. So were there any questions Vikas that you had for us?

**Gurtaj Alag**   25:12  
School.

**Vikas Ranga**   25:20  
Mainly from data side, like, you know, for all this those data that we need, we need kind of sheets where you can give us the field name and two, three rows so that when we will build the database that will be more close to like reality.

**Shruti Sathe**   25:42  
Meaning like what do you need? Can you give an example?

**Jang Singh**   25:45  
I, I think, I think Shruti, like Justin mentioned over there, that drop call, right? We can see access failure to that type of tab, we can add more.

**Vikas Ranga**   25:45  
Okay, okay, sure.  
Yeah, like say, we have the data of these, this one, like, you know, drop call my ADL.  
report or here market shares of generate sort of the feedback like you know feedback that showing more like of a CSAT.  
And PS, but the feedback data will be more like there can be a field feedback form on the UI that user like in a fills that form. Then we forget the data more like one line of description and details so.  
Just need the field names and maybe here also when we see it when we are getting the data from like say like a snowflake or.  
or faults then the data will be in the form of like you know tables and each table will be having the field names and so need to have say say if you can give 20 or  
And like a tables data with the field names, these these will with the fields, or we can do that as well. We can get the some data generated from our side and share with you that, and you can like you know.  
Verify it once.

**Shruti Sathe**   27:31  
Yeah, I think that will be, can you open that PRD document since you're sharing your screen?

**Vikas Ranga**   27:35  
S.  
OK, that you, you, you give.

**Shruti Sathe**   27:41  
Whichever I think in your document also there was that table with all the

**Vikas Ranga**   27:42  
That one.

**Shruti Sathe**   27:48  
feel like the data inputs that we were looking for. So yeah, I think you can open your document.

**Vikas Ranga**   27:56  
Okay.

**Gurtaj Alag**   28:00  
Okay.

**Shruti Sathe**   28:12  
So yeah, I think if you go down in this document, there was like, yeah, this one, right? So basically all this, the subcategory column, that is basically all the fields which are there, right, for the engineering side of things. So.  
I think what we are trying to...  
See, is there a way that you can, you know, for example, for network performance KPIs like sign R, RSRP, throughput, is there a way to, you know, like generate dummy data through AI or whatever, and then, like, for example, having few rows for a sign out like that, like...

**Vikas Ranga**   28:49  
Yeah.

**Shruti Sathe**   28:56  
Can you generate the dummy data and then we can, because I'm not sure for like customer or marketing share and all like how will we generate the tabular data? I'm not exactly sure on that part. So maybe if you can have some dummy data, then we can review and then if any more feedback.

**Vikas Ranga**   29:00  
Yeah.

**Gurtaj Alag**   29:05  
Yeah.

**Vikas Ranga**   29:10  
Got it.  
Sure, sure.

**Shruti Sathe**   29:15  
You know, input is needed from our side. We can add to that, so...

**Vikas Ranga**   29:20  
Sure, sure, yeah, yeah, we'll do that.

**Shruti Sathe**   29:20  
That may be like a better and easier approach.

**Vikas Ranga**   29:25  
Yeah, sure, sure. Um, we'll do that for that.

**Shruti Sathe**   29:29  
Yeah.

**Vikas Ranga**   29:30  
So I have a call in one minute though that I need to jump on over there. Sorry, sorry for that. Kind of I need to take that call.

**Shruti Sathe**   29:40  
Yeah, no worries. So I think for now we are good, right? I mean, if there is anything else, then we can... Kajal, we do have another call on Wednesday, right? Or I saw it was cancelled or something.

**Vikas Ranga**   29:41  
S.

**Kajal Yadav**   29:53  
SN.

**Shruti Sathe**   29:54  
Do we still have it, or?

**Kajal Yadav**   29:56  
Ohh.  
Yeah, I need to check.

**Gurtaj Alag**   30:01  
So, one.  
One thing I mean, and then, but you know, this crossing the road right now, question because...

**Vikas Ranga**   30:18  
I.

**Gurtaj Alag**   30:19  
The predictive is the prediction prescriptive will have like 2 open loop closed loop openers with all the reactive.  
proactive, diagnostic, predictive data.  
It.  
basically gives what action needs to be taken. So prescribes, that is prescriptive means prescribes the action. Take this action, corrective action, and the open loop is that it doesn't take the action, it gives the action to the related person.  
To check the QA check, what you were mentioning.  
And the...  
Once.  
It is certain that the issue has this corrective action which fixes it. The open becomes closed loop, meaning you check back. Next time that issue happens, it automatically that action will be taken. So it becomes like a memory book, historic, the more prescriptive.

**Shruti Sathe**   31:07  
Yes.

**Gurtaj Alag**   31:23  
Executive actions are vetted by an engineer, they become like a catalog of next time that issue happens, take the action and new learn, so new learnings will keep on coming, and the old ones just become part of that knowledge set.  
So I just want to mention that because if that makes sense.

**Shruti Sathe**   31:48  
I believe he had to join another call, but maybe not sure if Mitali can take up this question or we can discuss it on.

**Gurtaj Alag**   31:53  
Ohh, OK.  
Yeah, yeah, and, and Mitali, if it was possible to stare basically what Vikas said, the link so that we can at least leave with it and provide feedback from the next call.  
Is it possible, Natali?

**Mitali**   32:13  
Sure, I'll ask Vikas, like he will share it over WhatsApp group or email.

**Gurtaj Alag**   32:16  
Ticket.  
Email, yeah, yeah, ticket, and then Kajal can, Kajal just asked Vikas if that link can be shared, so we can just play with that the framework, the way it is being built, because I think that was the one that you Vikas showed, was it made on Figma?

**Kajal Yadav**   32:25  
Yeah.  
Okay.  
Bing.

**Mitali**   32:39  
Yes, I guess, yes, yes.

**Gurtaj Alag**   32:39  
Natali.  
Yeah, it, it, yeah, for Sigma, right? Yeah, OK, yeah, so yeah, if you can send me the the as the Sigma link, at least that would be the first step.  
Okay.

**Mitali**   32:52  
Yeah, sure, I'll ask him.

**Shruti Sathe**   32:53  
Yeah.

**Gurtaj Alag**   32:55  
All right.

**Shruti Sathe**   32:55  
Yeah, Kajal also, I don't see a meeting on Wednesday. So can you put it back on the calendar? Because I think we were going to have the meeting twice a week, right? So.

**Kajal Yadav**   32:59  
Yeah.  
Mhm.

**Gurtaj Alag**   33:06  
So was it Monday, Thursday or Monday, Wednesday? I think Monday, Thursday.

**Kajal Yadav**   33:08  
Yes.

**Mitali**   33:10  
Yeah, it was Monday and Thursday.

**Kajal Yadav**   33:10  
It's on Friday.

**Mitali**   33:14  
In the last call, we have decided to keep the meeting on Monday to Thursday, Monday and Thursday only. But I can see two, three scheduled meeting like on Thursday, on Friday. I guess it is twice a week only.

**Gurtaj Alag**   33:19  
Yeah, yeah.  
Yeah, it does.  
Yeah, it should be Monday and then Thursday. Yeah.

**Mitali**   33:30  
Auspect, yes.

**Gurtaj Alag**   33:31  
Twice OBK.

**Shruti Sathe**   33:37  
Yeah, Kajal, can you like clean it up and cancel any other meetings which are there?

**Gurtaj Alag**   33:37  
Oh.  
Yeah.

**Kajal Yadav**   33:44  
Okay, yeah, I don't.

**Shruti Sathe**   33:45  
Yeah, so Monday and Thursday, I guess, right? So, yeah.

**Gurtaj Alag**   33:45  
Okay.

**Gurtaj Alag**   33:48  
Yeah, so I'll I'll drop off, uh, Shruti, uh, you can, yeah, take care of the the, but I'll drop off now, but thank you so much, Natali. Thank you, Vikas. Bye, bye.

**Shruti Sathe**   34:00  
Yep, thank you.

**Mitali**   34:01  
Thank you.  
Connect.

**Kajal Yadav** stopped transcription