**Weekly SyncUp with Neurogent-20260602\_220359-Meeting Recording**

June 2, 2026, 4:34PM

1h 32m 16s

**Satyajeet Rout** started transcription

**Vikas Ranga**   0:05  
Yeah, it's next time starting.

**Shruti Sathe**   0:05  
Okay, all right, yeah, that's fine. Okay, so let me share my screen.  
So this is the PRD document that I had shared with you earlier and I'll send it to you after this meeting as well because we have made some changes to it. So basically the...  
But...  
Like for all this time, what we are talking about, right? Like the tool or the, not a tool, I would say like the platform, what we are intending to build. We are, you know, basically the idea is to like build a platform or a marketplace where it won't be, like we are not building a tool for a particular use case. What we want to have is like a marketplace where.

**Vikas Ranga**   0:34  
Yes.

**Shruti Sathe**   0:59  
will have all the, you know, several types of data available pertaining to telecom industry to start with. And then based on, you know, all the data input that is available and all the data resources which are there, any company, you know.  
can pick a use case or the problem statement that they have and basically the marketplace or the platform has the capability to, you know, cater any kind of customized use case that any company wants to build. So we have like 2, 3 use cases to start with in our mind, which will, you know.  
Kind can can be built using this tool, which you know we can showcase as an example, but eventually the goal is to, you know, not build a tool which is specific to a particular XYZ use case. Basically, we want to have it like an open marketplace idea, which you know...

**Vikas Ranga**   1:57  
Yeah.

**Shruti Sathe**   1:57  
which can analyze the data and then obviously it is AI enabled and then we will pitch it basically as an AI enabled marketplace which can cater to various use cases for companies, you know, obviously starting in the telecom sector.

**Vikas Ranga**   2:00  
Yes.  
Yeah.

**Shruti Sathe**   2:17  
like operators, for example, or, you know, small, medium-sized companies here in the US. But then we don't want to limit to the telecom sector. We also want to expand the usage for this platform to, you know, data center companies, for example, or fiber companies or...

**Vikas Ranga**   2:19  
Yeah.

**Shruti Sathe**   2:37  
cellular Wi-Fi satellite companies. So that's what we have in our mind. So yeah, that's the idea basically. So basically having the, you know,

**Vikas Ranga**   2:39  
Yeah.

**Shruti Sathe**   2:49  
Like I said, AI enabled tool, which obviously does all the reporting, doing the data analysis, which can have different like data trends, but then ultimately putting the magic and power of AI in it and then, you know, you know, doing all the predictive, prescriptive data analysis as the end goal.

**Vikas Ranga**   3:00  
I.

**Shruti Sathe**   3:10  
So that's like a high level idea what we have in our mind. So let me go through this PRD that we have. So let me just start with an example use case. So I think it will be easier to understand the PRD accordingly. So.

**Vikas Ranga**   3:17  
I.  
The.

**Shruti Sathe**   3:29  
You're able to see my screen, right?

**Vikas Ranga**   3:31  
Yeah, yeah.

**Shruti Sathe**   3:33  
Yeah, so basically this is one of the use case which can be, which is a use case for, you know, any operator, cellular operator company. So say, for example, say here you take T-Mobile or in India you take Reliance Jio, for example, right? So say a company like that, if it has a low market share.

**Vikas Ranga**   3:35  
Just.  
Yeah.

**Shruti Sathe**   3:54  
compared to its competitors, right? And say the reason for the low market share is because of the customer churn that is happening, for which the root cause is basically the network issues, right, which is causing the company's revenue degrowth. So that's the problem statement or the use case. So what this platform, or one of the use cases for this platform will help to do is,  
So the idea is to have like a GIS or a mapping layer available, right? So that the engineers can, you know, visualize the data in terms of, okay, various zip codes which are available, city level. If you take like cellular company example, like site level zip.  
code level, area level kind of data. So basically say if we take a city, for example, Seattle, and it's split in like various zip codes or the metropolitan statistical area, right? So we'll have that visual on that use case or the tool. And basically for the data input, we will have several data inputs coming from the.

**Vikas Ranga**   4:42  
Yeah.  
Star.

**Shruti Sathe**   5:01  
engineering side, like, you know, all the network APIs, say drop call rates, throughput latency. So that will be like the engineering data input. We'll have a marketing data input, like say, what is the market share, customer demographics, churn and all those kind of data inputs. The third layer of input will be from the customer point of view, like customer feedback, like voice of customer, trouble ticket.  
**w**there needs to be some upgrade or modification done to the existing site. Or it can tell, help the leadership team make a decision that okay, there is a certain area in Seattle or multiple areas in Seattle where the market share is also low, but the network performance is decent. So.  
That's where you know maybe the sales or marketing needs to be worked on to, you know, improve like the customer feedback or say there is an area where the market share is good, but the and the performance performance is also good, so this is the place where you know.

**Vikas Ranga**   7:57  
I.

**Shruti Sathe**   8:08  
The network needs to be optimized in a better way, and then it can help the leadership team make, you know, decisions, how to, you know, invest properly in what categories and do all the business strategy and all, so that is the end goal, or this is one of the use case, you know, what.  
We have in our mind, but then ultimately this is more of an operator-based use case, but say, so the idea is to build a marketplace having, you know, similar data sets, which can eventually then we can, you know, go and show it to like a data center company or any other company which.  
which also has like similar data inputs. But I think the idea is once we have like the skeleton ready and we know now it's working, then I mean, adding more data inputs is just like a like repetitive thing. So we can do that. So, so yeah, this is I just wanted to start with the use case for that.  
you have some idea what we are trying to build. So any questions so far? Because I'll just then go through the detailed PRD that we have, which is basically drafted on taking into consideration this example only. So.  
Any questions so far, or maybe Gurtaj, do you want to add anything so far?

**Gurtaj Alag**   9:32  
Yeah, I think covered very well. I will tell you, Vikas, we take a balcony view. So balcony view, okay, what are we trying to do? So create a marketplace concept and the marketplace concept is the layer fabric.  
where the client, the user, will have the ability to build his own use cases. So in order to just showcase that concept, obviously we'll build one or two use cases ourselves. So there are three dimensions, if I can, and I think.  
before Shruti shows the PRD 3 dimensions one.  
There is a data source layer. It's important, I know, I mean, you already know everything is about data, but the categories of data. Every company, okay, in telecom to begin with, will have marketing, some network KPIs, some customer related data, some engineering import, some third party, some crowdsourced.

**Vikas Ranga**   10:30  
Just.

**Gurtaj Alag**   10:38  
So I have certainly this created like an Excel file. What are the data? So that's one data. Every company will have this. I can go to Starbucks. I mean, I obviously will go to telecom first. They will have some marketing data. They will have some KPIs showing their.

**Vikas Ranga**   10:39  
So.

**Gurtaj Alag**   10:57  
Performance, and they will have like some customer feedback, they will have some competitive analysis. OK, so that, so there are these general categories, we will obviously tune it for telecom, which has fiber data center, CSP, you know, all of the above satellite companies, so that's one then.

**Vikas Ranga**   11:09  
S.

**Gurtaj Alag**   11:17  
The previous way of doing it.

**Vikas Ranga**   11:18  
Yeah.  
Yes.

**Gurtaj Alag**   11:25  
Waugh.  
reactive reporting, which are some trends. You know, he can now use, he's got sources say historic trend. He wants to see the network KPI drop call rate and then on the other he wants to see the churn. So just reporting. Okay. Second, once we have reporting, he can do alerts because I mean, it's a threshold if the drop call rate or a KPI degrades.

**Vikas Ranga**   11:41  
Yeah.  
Yes.

**Gurtaj Alag**   11:50  
Send me an alert and then, because now you have all these data, there is a correlation engine. So anomaly detection is in the threshold, but correlation engine is you have all this data, he's able to correlate and he's able to do all these things, right? So that's one layer. So the second dimension. Third is on at the marketplace level, you have like.  
Wizards to build a marketplace and I'll have Shruti actually showcase and it'll bring more clarity, but at that layer you're now doing predictive and you're doing doing prescriptive advanced ML and AI based, you know.  
So that that's so I see 3 dimensions the way we have to build it, but keep your questions to yourself for like a little bit more time. Shruti can go through the PRD. Satyajeet will show.  
You know what it looks like very very raw and then we'll show you the last stage also

**Vikas Ranga**   12:46  
School.  
So.  
So.

**Gurtaj Alag**   12:54  
So, anyway, you keep your thoughts for like another 15 minutes, Shruti, go on, yeah.

**Shruti Sathe**   12:57  
Yeah.  
Yeah, yeah.  
Yeah, so based on the use case that I just showed, right? So this is basically, you know, a very draft PRD and then we can, you know, modify it as we go and then any questions you may have, I mean, because like, we'll have recurring meetings, so, so yeah, basically the intent is to, you know, build a marketplace which we are we want to name Platform X, so it can do like different.  
use cases like optimization, which we are, you know, calling OptoX or the use case that I showed, the analytic X. So basically, you know, all the data analytics and all those things. So yeah, so basically that's the intent. So to build a marketplace, you know, for various use case that, you know, involve.  
engineering side, marketing side, customer related data with all the demographics information and the GIS or the map layer available. And then example can be like an RF engineer, agentic bot, AI bot, or, you know, which can be used for any cellular network operator company.  
which can, so that this is another use case. So like, you know, it can help RF engineer do its daily tasks. So like there are so many tasks that an RF engineer, you know, does on a manual basis daily. So intent is to, you know, automate some of those tasks and then have some.

**Vikas Ranga**   14:25  
Okay.

**Shruti Sathe**   14:28  
reports available which can, you know, actually help the RF engineer focus on the solutions rather than focusing on finding, you know, what the problem is or where the problem is. So, and I'll send you this document so you can obviously read it and then we can, you know, take any questions you may have.

**Vikas Ranga**   14:38  
H.

**Shruti Sathe**   14:48  
So basically, all these are the data inputs that will be going in the platform X, right? So first is the engineering, telecom engineering data, where we have all the key performance indicators, which, you know, indicate how the network is performing.  
So you have the key performance indicators like the signal to interference noise ratio, you have the RSRP. These are all like RF KPIs that, you know, are basically helpful to, you know, monitor how the network is doing or how the network is performing.

**Vikas Ranga**   15:17  
Yeah.

**Shruti Sathe**   15:26  
You have the end user throughput, accessibility KPIs, retainability KPIs, like how is the handover being done, or what is the call drop rate, radio link failure. So all these KPIs will be, you know, part of the engineering data set that we will have on the platform.

**Vikas Ranga**   15:32  
Stop.

**Shruti Sathe**   15:47  
And where do these KPIs come from? So what is the data source, right? So they typically in any operator's company, there are so many performance dashboards which are there, which are like Power BI dashboards or any operator has like a proprietary tool. For example, there is a tool called TPIM in.  
T-Mobile or Imnos tool, so those kind of data sources, so all these KPIs will be, you know, taken from all these data sources. This is more for the this is part of the tool that Satyajeet has built, so I'll talk about this when we show when we show you the tool.  
Another is like there is so basically then you operate a company there are there are so many parameters, right? Like and say there are like XYZ counters and parameters which are set to like a particular one, two, three value for example. So at least in I mean we are taking our example from T-Mobile so there is like an.

**Vikas Ranga**   16:29  
Stay.  
No.

**Shruti Sathe**   16:50  
Excel sheet that is maintained with all the parameters, right, and say if there is any change in the parameter for any particular county or any particular site, then you know, there can be an issue. So basically that kind of automated stuff like, you know, checking the parameters for any site.

**Vikas Ranga**   17:05  
In.

**Shruti Sathe**   17:10  
against the golden parameter set which is available and then flag the parameters which are non-compliant. So all that kind of parameter data, you know, typically comes from the vendor OSS. For example, in T-Mobile here, you know, all the hardware which is out there is basically Nokia and Ericsson hardware.  
So it comes from like Nokia, Ericsson, OSS. So that is the data source for all these parameters. And then there is network ticket. So there are, if say there is any, if say any site is down or if there is any other issue going on with a particular cell site, there is some ticket which is associated with that, right? So.

**Vikas Ranga**   17:32  
Yeah.  
So.  
I.  
Is.

**Shruti Sathe**   17:54  
monitoring you know all the network tickets which comes from any operators proprietary ticketing tool. There are alarms say if there is any hardware issue on a particular site or there can be like different kind of alarms on the site. So monitoring all those alarms which also you know.

**Vikas Ranga**   18:05  
I.

**Shruti Sathe**   18:13  
come from like any vendors, OSS or any companies, UNMS for example. Then, so this is, I mean, all the basic information that we surely want to have. Another thing that this tool or this platform can be capable to do in future is to, you know.

**Vikas Ranga**   18:15  
So.

**Shruti Sathe**   18:32  
So that's why it's still in red, because this is more on maybe we can call it like a future roadmap. It can also help, you know, RF engineer too. So all these tasks are, you know, done by the RF engineer manually. So ultimately we can set a goal that, you know.

**Vikas Ranga**   18:42  
Yeah.

**Shruti Sathe**   18:51  
All these tasks can also be automated, like, you know, if there is any particular antenna on the side, then you know, modifying the azimuth or the antenna direction, optimizing the power levels for that particular site or the antenna, adjusting like the neighbor lists or frequency allocations. So this is like a very...

**Vikas Ranga**   18:52  
Yeah.

**Shruti Sathe**   19:13  
in-depth telecom thing. So that's why I have kept it in red because it is, I mean, the ultimate goal is to also add on all these functionalities. But to start with, we can, I mean, keep them aside for now because it's more of an add-on thing once we have like the platform ready basically.

**Vikas Ranga**   19:27  
Yeah.

**Shruti Sathe**   19:34  
Then, you know, have also RF planning data as the data input where, you know, we import data from tools like Planet, Atul. So these are all like RF planning tools which are, which any company uses. So like the intent we were also actually looking at, you know,  
If there is any coverage map which is available, then is it, you know, possible to let me actually show you as an example.  
So say if there is any coverage map like this, right, which shows you like, okay, this particular area, it has like a 5G coverage or LT coverage or stuff like that. Since we don't have the raw data, we were actually looking into seeing that, you know, is it possible to like scrape some raw data or get some dummy data, you know.  
which can give us all this like coverage information on that platform. So that's what it is. So this is all engineering side of things. Then comes the marketing data, right, which I showed in the use case. So like have the marketing related data input, like the market share, any company's market share.

**Vikas Ranga**   20:32  
S.

**Gurtaj Alag**   20:36  
You.  
Yeah.

**Shruti Sathe**   20:51  
customer demographics information, shown information and all that. Have like a customer feedback information. So imagine like one would be like engineering data set, one would be marketing data set, third would be like a customer.

**Vikas Ranga**   20:56  
The.

**Gurtaj Alag**   21:06  
I think, Shruti, one thing is missing. I don't know the the drive test data, like, maybe like, I don't know, we do, we didn't put that. OK, we can add that. It says there in the Excel file. OK, that's fine.

**Shruti Sathe**   21:18  
Yeah, we can.

**Vikas Ranga**   21:33  
Yeah.

**Shruti Sathe**   21:34  
root matrix, sukla, but I mean these are all  
I mean, we did some research. These are not available like, you know, freely and because it's obviously a proprietary data, but since you have an expertise in this area, you can, you know, help us to gauge if we are, you know, able to get such kind of data available on that platform.

**Vikas Ranga**   21:46  
Yeah.

**Gurtaj Alag**   21:56  
See, see, one thing I, you know, I won't tell you that actually this PRD, like we will, you know, work on a little bit cleaning it up, but I, I want to tell you one thing that was, you know, I think this is first part is the data sources, data categories.  
The common ones in in telecom, those are categories, and then once you have, you know, I don't know, like every category probably has like an AI agent, which I was, you know, whenever you do, you have to do data ingestion, you have to do the the the data, you know, monging.  
aggregation, transformation as an example. So the agent is able to do that for marketing, okay? It's a connector in the previous world and in the new way of doing it, maybe there are there are there are better ways of doing it. So once you have that figured out for all these categories, then you will come on to, you know, some kind of.

**Vikas Ranga**   22:41  
Yes.

**Gurtaj Alag**   22:56  
reporting, you know, seeing it on a GIS map or basically seeing it as reports like I was mentioning, you know, like a trend. I'm able to pull various, you know, because we don't have all the data nowadays, like what do I want to see together or separate or.

**Vikas Ranga**   23:12  
Ashish.

**Gurtaj Alag**   23:15  
Right, then I'm able to do alerts, then I'm able to correlation, so this is 1 layer and the last part which I'm really I think that is what once we have that the predictive and the prescriptive one is when the marketplace see Vikas why we went marketplace.  
In some cases, when we show one or two use cases, actually, there are multiple use cases entwined in that one PRD. So when you saw that picture, it's a business plan marketplace. In the same PRD, we are even talking about RF bot. Any of those tasks a person wants to do.

**Vikas Ranga**   23:48  
Yes.

**Gurtaj Alag**   23:52  
an audit. It's an RF bot. You are able to create, if that is the wizard you want to create for you, okay, in the marketplace, you create that, you have the data set, it will start doing that for you. You are creating, you are giving the ability to the user to create using the wizard, either AI bot to do that function.

**Shruti Sathe**   23:53  
It.

**Vikas Ranga**   23:57  
SN.  
Yeah.

**Gurtaj Alag**   24:12  
I mean, small ones, or it's a very complicated use case. Actually, you know, let me hold my breath for a little bit more. I think, let's look at who's showing this now, Satyajeet or...

**Shruti Sathe**   24:16  
I.

**Vikas Ranga**   24:16  
Just.

**Shruti Sathe**   24:27  
No, no, it's me. So basically, yeah, I'll just quickly show you this. So basically, just for, because just for the ease of viewing, whatever data or information we had in the Word document, we just, you know, listed all the data inputs here in the Excel file. So that, you know, it just helps, like what kind of categories are there and then.

**Gurtaj Alag**   24:29  
Okay, yeah, go, go for it, yeah, go for it, yeah, yeah, yeah.

**Shruti Sathe**   24:50  
what kind of data input goes in each kind of category. So this is just a view, whatever there is there in the Word document, you know, we also listed it in an Excel file, but I'll have Satyajeet share his screen and show you, I think that will maybe, you know, give you a more better idea what we are talking about. So.

**Vikas Ranga**   25:01  
I.

**Shruti Sathe**   25:11  
Ohh.  
Yes, Satyajeet, do you want to share your screen?

**Satyajeet Rout**   25:17  
Yeah.

**Shruti Sathe**   25:19  
Yeah, so based on the PRD or the business plan use case that you saw, right? So, basically, this is a very draft raw tool that you know Satyajeet built. So, like I said, you know, so the name here is...  
Platform X, which is our, so Satyajeet, yeah, you can make it in capital, but that's the name of the marketplace, and then you have, like, on the left side, you will see, like, there is an engineering data set, so if you, yeah, if you all the subcategories in that are like all the KPIs are there.  
So, you know, KPIs like the sign R, RSRP, throughput, say on the, yeah, there is like a filter where you can filter based on LT technology or 5G technology and even in LT or 5G there are multiple bands, right? Because there is multiple spectrums.  
from bands which are owned by any operator. So you can filter basically on any band if the engineer wants to see. Go to the other one, alerts.

**Vikas Ranga**   26:27  
Bing.

**Shruti Sathe**   26:33  
Yeah, so like say there is any alert or alarm coming on the site. So, you know, it will show you and then based on the idea is to also, you know, the AI agent will tell like what is the root cause, RCA root cause analysis for this and then.

**Vikas Ranga**   26:34  
See.

**Shruti Sathe**   26:55  
It can also, you know, give a solution so the RF engineer maybe has to just, you know, think more about the solution or what to do and then take the action as needed. Then you have.

**Gurtaj Alag**   27:08  
See, see, one thing I want, it is one thing I want to tell you that, you know, like, I mean, again, this is like very rough. This is actually, it has a lot of imperfections, a lot of, because you know, the idea was...  
Actually, these views will not be available. I mean, you have data and then you know you will build a view, the view that you want, meaning like it's a historic data. Obviously, we didn't have it. We didn't intend was just to show you. I think Vikas what the focal point is the left side.  
Are the categories of datasets?  
Right, that will be imported from any company.  
Then, like I said, once you have all those data sets, then...  
The journey is you want, I want to do reactive visualization. I want to do proactive thresholds. I want to do RCA correlation engine. This is the spot what you're seeing right now. The user will create, the user will create the view, the alert.  
and the RC engine will be the secret sauce to correlate not only what he has put in his view for a threshold or for a reporting, because you have all this various data sets. So that's one. And then, yeah, Shruti complete this. I think I'll.  
I'll clean up basically the concept, because, you know, these are all.

**Shruti Sathe**   28:33  
Yeah.

**Gurtaj Alag**   28:36  
I mean, these are thoughts which are in different directions, actually, and you know, like I, and I'll try to, you know, clean up the PRD or explain what the end result we are wanting, but go on, Satyajeet, go on.

**Shruti Sathe**   28:49  
Yeah, yeah, then yeah, go to the faults, Satyajeet.  
Yeah, so basically that will be information on the site faults, the parameter audit that again go on the left, yeah.  
Yeah, like all the comparison with the.  
the golden parameter set that I talked about. Go again to the left, go down, I think, yeah, we, yeah, then there will be like a...  
That's fine, we can show the customer feedback, for example. So, that was all like the engineering related data. This is all like the customer related feedback. So, like ticket, so I think Satyajeet tried to, you know, have some dummy data from.

**Satyajeet Rout**   29:23  
Six.

**Shruti Sathe**   29:39  
Yeah, and then voice of customer.

**Satyajeet Rout**   29:42  
It's now empty currently.

**Shruti Sathe**   29:44  
Okay, yeah, then go to the GIS.

**Gurtaj Alag**   29:48  
Yeah, and, and, and G.S. something, yeah.

**Shruti Sathe**   29:50  
Yeah, so like the data trends, for example, like this, all the dashboards which are available.

**Satyajeet Rout**   29:59  
In GIS, we will apply GS on every feedback.

**Shruti Sathe**   30:01  
Right, so GIS is basically like a master view, which so basically the mapping such view can be basically the idea is that, you know, having such view available for the top level like everywhere so that the engineer can, you know, see the view in like a mapping.  
kind of view.  
And then I think marketing you got something or...

**Vikas Ranga**   30:27  
Yeah.

**Gurtaj Alag**   30:32  
See, I'll, I'll, this is, this is good just to, but I, like I said, this is far away from, you know, what I have in my head and I'll try and my problem is that I mean, I'm not very good at writing PRDs, but I will explain, I'll try my level best to learn the language of PRD, but I wanted you to just look at...  
this and I'll try to explain what I'm wanting. Because if we go with what we are showing, nobody will, you know, what I have in my mind is so advanced because based on all the people that I've met, I know exactly that kind of product does not exist basically. Is the reason I'm very excited to.

**Shruti Sathe**   30:56  
Yeah.

**Gurtaj Alag**   31:12  
you know, for this partnership because when we create that idea that MVP, people will get it immediately. When I'm showing it to SVP, he will understand it immediately. They are not going to be caring about all that you're seeing right now. I already know that, right? But this is only to show you because you're also building, you know.  
a ground up kind of thing. So it is, it is far away from what I have in my mind. I can tell it to you, you know, but yes, it is directionally the foundational step to show somebody basically what does telecom data look like. These are various categories and some data sets, but what idea I have in my mind, I will, I will share.

**Shruti Sathe**   31:50  
Sathe.

**Gurtaj Alag**   31:53  
Once Shruti is done, yeah, go on, Shruti. Sorry, I get excited because you know, yeah.

**Shruti Sathe**   31:58  
Yeah, no, no, that's fine. Yeah, and if you go to platform X agent, I think is that the number down, ohh, the coverage maps, do you have anything? Yeah, so the idea is to also have like a spectrum map.

**Vikas Ranga**   32:11  
Yeah.

**Shruti Sathe**   32:13  
Yeah, go to the platform X agent. Is that the view that we were talking about?  
Okay, yeah, so this is like the front end view or the marketplace, you know, what we had in our mind. So having something like this, for example, these are like 2 use cases that we have shown, like the analytic X, which is the business case example, and then opto X. So basically the intent is to, you know, a customer can, you know, basically.

**Satyajeet Rout**   32:23  
Yeah.

**Shruti Sathe**   32:41  
Um...  
input or have any kind of use case that he or she wants and then have like a use case or a front end view like this. So and then there will be like the AI agent doing all the work.

**Vikas Ranga**   32:48  
Yeah.

**Satyajeet Rout**   32:58  
Yeah, it's going to dummy.

**Shruti Sathe**   33:01  
Yeah.

**Satyajeet Rout**   33:02  
What do you like?

**Shruti Sathe**   33:07  
So yeah, I think that's what we wanted to show. So we can, I think I'll stop talking and then yeah, Vikas over to you too.

**Satyajeet Rout**   33:07  
Two.  
If you...  
Uh, no, we we have customer market share.

**Shruti Sathe**   33:19  
The demographics, okay, okay.

**Gurtaj Alag**   33:24  
See, I'll tell you, because basically...  
Once we have all these categories and you know the categories, obviously there is dummy data, we will have to start with the, you know, AI can create simulations for each of these categories, historic data also can be created, so that's just the first step.  
After that, what I'm saying is, yeah, if person wants to see these kind of reports which are pre-made, great. But then he wants to create his own. So there are two pieces. I want to separate them. So one is normal reporting reactive, and then the middle, so actually three, and one is your RC engine.

**Vikas Ranga**   34:05  
S.

**Gurtaj Alag**   34:07  
and the last is going to be the prescriptive predictive.  
Each of these he can use the marketplace wizard depending on what we I want to create only reports of visualization and only want to set some alerts so.

**Vikas Ranga**   34:14  
Yeah.  
I.

**Gurtaj Alag**   34:21  
Are you Vikas, are you following the basically the high level concept? I know the devil is in the detail, but what we have in our mind.

**Vikas Ranga**   34:31  
Yeah, yeah, yeah, yeah.

**Gurtaj Alag**   34:36  
Okay.

**Vikas Ranga**   34:36  
Yeah, sounds good. So maybe just want to check if you can share it up briefly.  
What value this will give to, like, you know, clients? So, just just want to know firstly from that point of view, if you put this with the value one, value 2, value 3, like this.

**Gurtaj Alag**   35:00  
See, the, the, I mean, I can, I don't even have to wait for, you know, image it, so the workflow automation right now, every company out there.  
They are doing all these things in silo. So first of all, you're getting all these data. When you go in front of a company, you are getting this is not just for engineering, it's not just for marketing, it's not just for the third party analysis, it's like all the above. So the value is first of all, you're getting all your forcing this concept of showcasing.  
People say single pane of glass. Trust me, I've gone everywhere. Even a company like Tmall does not have it. But I mean, they have all this data set in all different places. Second.

**Vikas Ranga**   35:41  
S.

**Gurtaj Alag**   35:48  
You're giving the power to the user. I am an engineer. An engineer wants to just create every time this thing happens, give me an alert. Today he doesn't have this capability. You, you, he will, he can do something for, you know, KPI, but maybe he cannot correlate it with, you know, an alarm. You give him that ability.  
to the user, you know, to create this. Last, it is always people typically are doing a static snapshot. There's a living.  
platform. Always running based on what you've created, providing value continuously, not once in a while. A lot of companies attempted this, but the problem was because of my personal experience in T-Mobile, I have worked across multiple departments.  
T-Mobile is now a very big company, but when I started 13 as a startup, so I worked in corporate strategy, I worked in marketing, I worked in the market and the region and the headquarter. It gave me a complete set of what needs to be coming together, first of all, in terms of data sets.  
Second.  
How do you simplify it for the user for workflow automation? And then can you start doing predictive and prescriptive? People are talking about it. I can tell you these are great ideas.  
Nobody is able to do it successfully because they are looking at everything in silo. But the answer, the secret sauce is first of all, building the right data set, swim lanes, and then those five steps that I keep on talking about, reactive, sorry, your reactive, proactive, diagnostic, predictive, prescriptive.  
I mean, everybody knows this. Nobody structured it in the right manner.  
So we are creating a marketplace. You create it. If you know your pain point, you create it. Or do you need our help? OK, we'll help you create it. Or there are some use cases like the RF bot example or the business plan. Based on our experience, we will have some things on the marketplace. It is like.  
You know, like your Android or your Apple marketplace, people have built a lot of applications. I mean, it works for some. But if I want to develop an app, the Android, the community or the Apple community can build an app which they think is valuable for their use case, their company, whatever the case might be.  
So, that is the value prop. I mean, you're talking three. I can, I can keep on, I can write a book on this thing, the value that this marketplace can create.  
It has never been attempted, Vikas. Let me put it in short. It is not, it has not been attempted at all.  
and with AI ML now, I see the possibility of creating it.  
Earlier it could not be done. You could have some database and some static reports, but now you can actually do that reactive till prescriptive, but in a marketplace concept. So I don't want to build something which nobody will buy. I want to show them the idea. Okay, by the way, we build these two use cases.  
You have your use case. Imagine we are going in front of somebody, your pain point.  
This is the data set. OK, build it, or we can help you build it. More than likely, they will choose help you build it. So it's a co-partnered creation of a use case in the marketplace, if that makes sense.

**Vikas Ranga**   39:18  
Okay, okay. Yeah, yeah, sure, sure. Then let us do one thing. We will go through to like a PRD and that's being done. And we will need this like recording link too. And then we'll do one thing. We will  
Generate.  
Our version of PRD that actually mainly do for our, like, you know, development team and it's having more nuanced details for development team and will give you that for your review and you can check if you find...  
anything to be changed and in that PRD that we will build for development team mainly, we will write some like doubts as well that we have. And so this will be the step that we will go through that and then

**Gurtaj Alag**   40:13  
Yeah.

**Vikas Ranga**   40:22  
Once we are finally, like, you know, the version of...  
priority that we will build that will be mainly like to come on the same page what needs to be done and when we are on the same page what needs to be done then our team can do that for them.

**Gurtaj Alag**   40:41  
Yeah, good. So, you know, good Pradeep, I like this. I want to tell you one thing, the PRD that Shruti showed, it is actually a little bit jumbled up and I'll tell you why I'm what I mean by that. Treat that PRD, there are data sources and there are multiple use cases possible with that data source. Some use cases are that.  
RF bot, he can do an activity based on any of the data set available. I want to create a bot which does a planning part. I want to do a bot which does operations. It looks at alarms all the time and as soon as an alarm comes, it, you know, alerts me, tells me correlation. Okay, this alarm came and there is a KPI degradation.  
So...  
Read Satyajeet, no, sorry, Shruti, when we send the PRD and the PRD.  
Let's keep it a live document, because I mean, I think I want Shruti, we have to make some edits in the in the PRD, even I'll work on it, but I will tell you what I mean by that. I mean, I think we have to be very clear, there has to be a data section in a little bit more structure, meaning we already have it, we just have to organize it, so one is...  
What are the various categories of data, right? Then, after that, there are there are there are two use cases we bought. OK, one RF bot and one that business case that the churn, the picture that that we've bought, that becomes a little bit more structured way of doing it, because once we have the data categories, then as a second step.  
I want the ability and the tool, just like Power BI. Remember, you can just make your own custom report, your custom report with custom alerting, and once you have done these two, a correlation engine is your RC engine, so that's one piece, and then the marketplace idea.

**Vikas Ranga**   42:20  
Yes.

**Gurtaj Alag**   42:29  
should be implemented across the board, meaning even if I want to create a report, I think for reporting, this is my view.  
out of the five steps of AI, the first three, we can do it in the conventional manner. It is only the advanced ML and AI part we use the marketplace concept. But I'll leave it to you again. I'm just throwing some ideas. I see three.  
levels, but maybe it is only two. Maybe it's data and then directly the marketplace. Marketplace can be used to, I won't only build a custom report. Okay, the visit helps you. Actually, maybe that's the right way of doing it. You have data sources and then, I mean, obviously people can go in each and click. GIS will be a common element. But supposing now I want to create a custom report.  
Right? That is the marketplace idea. Whether I want to meet reporting report, I want okay in the report some threshold, or I want to do an RC engine, and then ultimately the predictive and prescriptive is that historic, that MLAI coming into the picture. Where I'm going with Vikas, you will also have to help see you are the...

**Vikas Ranga**   43:16  
SC.

**Gurtaj Alag**   43:34  
AI ML expert with your team. I am just telling you the idea that I'm sharing is going to blow.  
People's mind because we have all the data swim lanes, but now the marketplace, you will have to tell me for these five stages. Maybe somebody does not want to create a RF bot. He just wants to look at reporting, but there's a marketplace concept.  
He can create a report. I mean, though it looks just like the current, but he's using the marketplace to create a report. Or I want to now have reporting as well as alerting. He uses the marketplace. No, I want to even include the RC engine. He again uses the marketplace. No, I want to even do a predictive. He uses again the marketplace. I want to do prescriptive. You see where I'm going with this. So there's data and then the...  
We just have the marketplace, the wizard.  
To create this, Satyajeet, can you? We will even again, I'm sharing everything with you, Vikas, to really excite you. Can you, can you show Sepri? Have a look at this, and I liked the attempt.  
and I, and I want you to have a look and we'll send you this link also.

**Shruti Sathe**   44:46  
Yeah.  
So, Vikas, just I sent you the, uh, it's okay, yeah, let let him go over it, and then I'll talk later, yeah.

**Satyajeet Rout**   44:52  
But...  
No, this one.  
Which one?  
This.

**Gurtaj Alag**   45:08  
Yeah, now look at this. Now just wait on this. So I really liked the way they were attempting to do this. I'm not saying this is perfect, but look at, look at, go up, no, no, go back, go back.

**Vikas Ranga**   45:22  
That's it.

**Gurtaj Alag**   45:22  
Go now, click on the any of the try marker factory here. OK, smart market.  
So now and look at the top, it says pick outcome, discovery wizard, AI design, one click, provisioning, live dashboard, observability, alert, auto fix, optimization. I don't think we should be using this because according to me there are five things and now that is where Vikas you will have to help us that.

**Satyajeet Rout**   45:34  
So, it's a...  
Yeah.

**Gurtaj Alag**   45:49  
I want to only do reporting or I want to do alerting. I want an RC engine predictive prescriptive. What is the life cycle of that? I don't know. In a marketplace, how do we do that? Because everybody will not be wanting to deploy RF agents. I just want to create an exec report.  
I create a market report every week. I'm looking at something. I just, you know, I can look at that data as just a reporting report, but I'm just showing you this. I'll just go through one example, Satyajeet.

**Satyajeet Rout**   46:08  
And.

**Vikas Ranga**   46:10  
Yes.

**Shruti Sathe**   46:14  
Oh.

**Gurtaj Alag**   46:20  
Yeah, next step.  
Even one.  
This dashboard was created, live dashboard based on your wizard. I mean, again, it's not perfect, but, and then observability came.

**Satyajeet Rout**   46:46  
I...

**Gurtaj Alag**   46:48  
Then came the alerting, auto fixes the RCA.  
And then on the optimization, according to me, it should be actually predictive and prescriptive. I mean, I don't know how they've done this, but predictive and prescriptive.

**Satyajeet Rout**   47:04  
Hey, just...

**Gurtaj Alag**   47:04  
So now once you created this, it's always whatever you wanted to create. Again, a person can stop till live dashboard, a person can stop till observability. We are enabling what I'm trying to, I just close this now, Satyajeet.

**Satyajeet Rout**   47:06  
I see.

**Gurtaj Alag**   47:20  
what I'm trying to share with you.  
Yeah, that.  
We have to approach it in such a way you're given the power.  
to the end user.  
He knows his pain point best. See, when I empower the client, he will give me, he will give us work. I don't want to go in and tell him that I know everything, you're a fool.

**Vikas Ranga**   47:40  
To.  
S.

**Gurtaj Alag**   47:48  
I'm telling you, that is why nothing sells in product, because you are trying to sell a mango. He wants a chapati, totally different category.  
I don't want to be, I want to give him such an amazing marketplace. The idea your services model services model his use case we will I have very intelligently Vikas if you will really think about.  
this idea. We have a platform, but it'll be a service building the use cases, whatever he wants to build. Because it is his pain point, he's building it along with our help. That is the way to approach this, if that makes sense. So I'll take a pause.

**Vikas Ranga**   48:36  
Got it.

**Gurtaj Alag**   48:37  
Yeah.

**Vikas Ranga**   48:39  
Yeah, yeah, yeah, yeah, yeah, sounds sounds good. Like, you know, like the no code, low code, like in platforms, or we can say the likes of those CRM, or like in Salesforce, and these platforms were built.  
In the says.  
era with this mindset where every client can like, you know, configure, receive their need. That's why they were doing the sales in various domains and so on and so forth. And in the  
AI world, you are saying, like, you know, that way, and so, so maybe let's do one thing, like, you know, we have got a lot of things now in one call, and let us go back, read, and, and like, you know,

**Gurtaj Alag**   49:33  
Yeah.

**Vikas Ranga**   49:40  
we will be back with our doubts then. So I have one more call in the next seven minutes. We need to be ready for that. We need to do some work for that as well. And so maybe got a lot of things now and

**Gurtaj Alag**   49:50  
Sol.

**Vikas Ranga**   49:59  
Let us walk this this week and, like, you know, will will raise our doubts and then we can, like, you know, go ahead from that point of.

**Gurtaj Alag**   50:11  
Good, and and I should, yeah, yeah.

**Shruti Sathe**   50:11  
Yeah, so sorry, just to since he has to leave. So I sent you a SharePoint link. Can you just check Vikas if you got it and if you are able to open that document so that you have access to the.

**Vikas Ranga**   50:24  
Yeah, yeah, I'm just checking.

**Gurtaj Alag**   50:27  
Yeah, that will be good, because you know, like Shruti, I think even the PRD, we can, I think, clean it, clean, we have to clean it up a little bit, meaning like the data set needs to be on the top and then, like, you know, maybe 2 use cases, you know, yeah.

**Vikas Ranga**   50:38  
No, it's saying to log in, so, so maybe you can put download and then share it up. OK, and you, you can you can keep.

**Shruti Sathe**   50:50  
OK, you have like Microsoft Office platform, right? So...

**Vikas Ranga**   50:54  
No, no, no, we are using like Google's.

**Shruti Sathe**   51:01  
Okay, okay, that's why maybe.

**Gurtaj Alag**   51:03  
Okay, and Vikas, a follow up call, one more thing, cadence wise, because you know, like, I'm really wanting the MVP, we are able to, like, before 7th of July, again, it's a very hard timeline, I don't know, like, because you know, I know now with AI, ML, MVP, whose idea.

**Vikas Ranga**   51:12  
The.

**Gurtaj Alag**   51:22  
Because I want to then, I just to tell you a little bit more idea, I will start engaging really big companies to give us, once you have created the simulated data, I mean, first we will use air simulation. I will then try and get in big giants.

**Vikas Ranga**   51:22  
Yeah.  
The.  
S.

**Gurtaj Alag**   51:41  
and show them this idea and then try to get data from them. So that is the idea. Cadence-wise, how do you want because now we are in, you know, really, it can't be once in a week. I think that'll be too less. It'll be at least, I don't know, you want daily stand up. I mean, is it like twice in a week?  
I just think about that and communicate to Kajal and she can then organize accordingly.

**Vikas Ranga**   52:07  
Yeah, no, it can't be more than two.

**Gurtaj Alag**   52:07  
I.  
Okay, cool, cool.

**Vikas Ranga**   52:13  
Times in a in a week, like, you know, we we don't want to be more on call, we want to work.

**Gurtaj Alag**   52:19  
For 2 days in a week, is there a particular day, you know, Tuesday, Thursday? I mean, we can pick whatever works, Tuesday, Thursday maybe, or Tuesday, Friday, you know, whatever it is. I mean, you know, you, you know, and Kajal can set it up another call every week, you know.

**Vikas Ranga**   52:36  
Yeah, so, but let me just go go back once and then, like, you know, so, so, so the goal is to have this ready in a like once time, so, so, so then maybe with this goal and let me go go back and and then I'll...  
I'll let you know, give you this view as well by when you can have a call and what will be our key calls during this one month as well.

**Gurtaj Alag**   53:02  
It.  
Exactly, exactly, exactly. Now you got it, you know, because I mean, whether it's four weeks, six weeks, I mean, it's very clear target, because you know, like, and then we can get into, like, you know, there are layers that we have to do, like the data first, and you know, so there'll be steps in this time, this work needs to be done, and then, yeah, you got it, I mean, you know, but with AIML.

**Vikas Ranga**   53:14  
Me.  
Thank you.

**Gurtaj Alag**   53:26  
I can tell you, I met somebody in T-Mobile last week, decision maker. They are doing MVPs in two weeks and I saw what he's created. So anyway, I mean, four to six weeks, I think we should be done with the concept, at least, which can be showcase to people, you know.

**Vikas Ranga**   53:40  
Got it. Yeah, yeah, then really good. Now I need to jump really.

**Gurtaj Alag**   53:45  
Okay, all right. Yeah, same as me. All right, take care. Bye bye. Bye. Bye.

**Vikas Ranga**   53:47  
Sorry. Thank you. Thank you. Thank you. Bye. Okay.

**Shruti Sathe**   53:50  
Yep, thank you.

**Shristi Singh**   53:52  
Bye.

**Satyajeet Rout** stopped transcription