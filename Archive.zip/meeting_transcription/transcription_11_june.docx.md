**PLATFORMX MVP Kickoff with Neurogent-20260611\_170003UTC-Meeting Recording**

June 11, 2026, 5:00PM

32m 34s

**Jang Singh**   0:09  
Huh?  
Oh.

**Shruti Sathe**   0:48  
Hi, Vikas.

**Vikas Ranga**   0:54  
Ohh, shipping, I know.

**Satyajeet Rout**   0:55  
Hello, everyone.

**Vikas Ranga**   0:58  
Anand.

**Shruti Sathe**   0:58  
Yeah.

**Mitali Lakhere**   0:59  
Yeah, hello, everyone.

**Jang Singh**   0:59  
I've got.

**Shruti Sathe**   1:00  
Hi, Mitali, hi is Vrushali.

**Shristi Singh**   1:02  
Hi, hi everyone.

**Mitali Lakhere**   1:03  
Hello.

**Shruti Sathe**   1:14  
All right, I think we have everyone.  
So, we can start.  
So yeah, I think because we did go over the PRD document that you had shared it, I mean, all the technical details and it like look good from what we had shared from our PRD. I think we just wanted to discuss with you. So in that PRD, you have mentioned like the phase.

**Jang Singh**   1:22  
Yeah.

**Vikas Ranga**   1:26  
Yeah.

**Jang Singh**   1:33  
Okay.

**Shruti Sathe**   1:42  
Zero or the phase one would be building one of the use cases, right, which is the agentic AI RF engineer persona. So, what our idea or what we are thinking is, is it possible in phase one to, you know, build the whole marketplace? I mean...

**Vikas Ranga**   1:51  
Yeah.

**Shruti Sathe**   2:01  
whole marketplace in a sense like just have like the dummy data available for you know the marketing and then the customer feedback, engineering, everything and then build like.  
I mean, we would love to have both use cases, but if we had to pick one of the use cases, we would, you know, rather go with the business case use case, which is about like the second use case, which, you know, has the engineering side of data, marketing data, customer feedback data. So we just wanted to discuss on that.  
part is that a possibility or because like if we if we go to any potential client and then I think it will be better to you know showcase them the whole marketplace obviously that okay we have all these like how Satyajeet had showcase the tool right the raw tool that he has built.  
like having all the data inputs from all different kinds of data sources like marketing, engineering. And then we can show them that, okay, this is 1 business case or business analysis use case, which we are calling it, which has, you know, all different types of data sets and it's not limited to engineering only.  
So we just wanted to know your thoughts, like that's what we had in our mind. Maybe I'll have Gurtaj, if Gurtaj, if you want to add anything.

**Vikas Ranga**   3:23  
No.

**Gurtaj Alag**   3:30  
Yeah, I think you covered it really well, Shruti. So basically, because like Shruti is mentioning, the goal is in the next four, six months, obviously there is a data layer. It's all synthetic data in those areas called, you know, marketing, engineering.  
Third-party customer experience, competitive analysis \- those are buckets which I think we provided and you documented it in the document, so that's one area, and then we showcase the market.

**Vikas Ranga**   4:06  
Best.

**Gurtaj Alag**   4:09  
place directly, but okay, these are the data layers and yeah, you can click and it'll give you a trend of the synthetic data in each of these categories as example, right? And yes, you can put some thresholds and yeah, there could be some RC engine, but more importantly, we build one or two use cases like.  
I would do the business, the positive ROI use case, as an example, and that goes through.  
The agentic AI, you know, that sequence of events. I think that would be.

**Vikas Ranga**   4:38  
The.

**Gurtaj Alag**   4:44  
the phase one which showcases, because you know, there are many companies out there showing a use case. I want to tell them, by the way, the marketplace is the secret sauce, and then you're building a use case on it. And by the way, this is an example of a use case, and we could help you build.  
your use cases, something like that. So I would not just do one use case, I would, the important part is the data layer and then the marketplace concept and then one example of how a use case can be set up. And there's an example of one that we've implemented, something like that.

**Vikas Ranga**   5:24  
Got it, got it. No, no, no, sounds, sounds, sounds good. I did this mainly that because I was thinking in a way to sell a use by by like by by showing the use case clients can get the value more rather than just showing.  
marketplace without the use case only because use case was the one that they can see the value as we are saving like a time of their team and they might need to deploy a lesser forks for that role and can save.  
Like, in the cost as as well, I mean, in my view, showing the value add was more there, but, but, like, as you are more closer to client and domain, so on and so forth, so you, you know, know that well deeply, so maybe...  
If you want that to be done, uh, like in it first, then like we can do so.

**Gurtaj Alag**   6:34  
Okay.

**Shruti Sathe**   6:34  
Yeah, I think that would be, I think, maybe a better approach, like, you know, building the front-end view of the marketplace, having the different data sources available, and then just picking up to begin with, pick up like the business case use case, and then, I mean, once we start showing it, we can, you know, also...  
add like, you know, we also have, we are also in the process of building like the RF engineer persona, which is like the engineering side of use case. So yeah, but yeah, I think to start with, we can, you know, build the business case use case because it has like different data flavors. It's not only.  
limited to engineering, but it has like engineering, marketing side of things, customer feedback and all those different data inputs, you know, available to it. So would it like change the timeline that you have mentioned in the document or how would it work? I mean.

**Gurtaj Alag**   7:26  
Like.

**Vikas Ranga**   7:32  
Yeah, yeah, we'll see it out and how much time will it take, but the plan will be nearly the same, so the plan was that we use this week to come on the same page what needs to be built, and we'll...

**Gurtaj Alag**   7:41  
Yeah.

**Shruti Sathe**   7:42  
Mhm.

**Vikas Ranga**   7:50  
Come on the same page on the UI UX as as well, so maybe what what we can do the call that we have on like a Monday that we can use to go through to the like, you know, UI UX of what we will be building and.  
If there will be any feedback on on that that you can give, so maybe we we can try to share the UI UX by, like, like, like in tomorrow only, so that, like, you know, any feedback that that UI UI UX, you click and give it and by Monday we can, like, can freeze that.  
And then we will use the next two weeks to build, and so, but that's the week one, week two, week three will be for build, and week four we can do like in a QA, and so the plan is just to go ahead in this like a four weeks.

**Gurtaj Alag**   8:44  
You know, like, I won't tell you one thing that...  
What Satyajeet created? You know, basically you were seeing the data categories. My point is each of those data category has got multiple.  
subcategories. Example, marketing has market share.  
That's a KPI. It has churn.  
Customer demographic, right?  
All these three, as an example, or or retail store performance, there is pseudo data.  
Now, the first, you know, the person clicks on...  
Marketing it shows, okay, now he picks.  
See.

**Shruti Sathe**   9:31  
Hold on, Satyajeet, can you start the recording? I don't think we we started the recording, yeah.

**Satyajeet Rout**   9:35  
Yeah, yeah, it is already, yeah, started.

**Shruti Sathe**   9:39  
Oh, is it? Okay, okay.

**Gurtaj Alag**   9:41  
Yeah, I'll tell you the way I'm thinking, Vikas, and you know, like, I think you will understand it because I want your imagination to go totally wild. I'm just telling you, like, you know, basically what I have in my mind is...  
So like I said, marketing is a category.  
with let's take one subcategory market share.  
Wait.  
The...  
Client can click and then like he sees whatever kind of reporting visualization you want to depict. It could be line chart, could be like a pie distribution, doesn't matter.  
In that category now, he wants to put a threshold that, okay, alert me.  
Only if the market share goes down.  
under a certain level. So that's the reactive, proactive, right?  
And then...  
I took only one category, say you got engineering data.  
which is showing for telecom a drop call. So drop call is increasing, is the reason the market share is going down. That is your third RCA engine.  
That example, right?  
So this is 1 area we've not even gone into the MLAI. That is where the marketplace becomes. So there is a static way of looking at things like I mentioned.  
Some reporting, threshold-based alerts, some diagnostic.  
Right.  
Most of the people are already doing this, but we have to do this. This is the groundwork.  
Then you come into the ML, AI, ML area with predictive prescriptive. So now you are building a used case.  
The use case is business plan. It will require all the various data sets and you are creating.  
That use case, obviously, will help, will help in the integration. The beauty of this thing is, Vikas, if this, if this concept in the first go is very powerful.

**Vikas Ranga**   11:46  
Yes.

**Gurtaj Alag**   11:53  
I see a complete services angle.  
You see where I'm going with this. You go to a client, if he likes this concept, we are saying you give us the data.  
And along with you, and by the way, the very use case is yours.  
You, you see what I mean? How are we building it is from the services engine that we will do it from India, you know, like new urgent, you know, to combine all these things, so now we are not locked into a product.  
Because if we do only one use case or product.  
It'll fall flat. We are going the concept. You can build your use case, your pinpoint, you know your pinpoint. You're showcasing. There's 5 steps in the journey from reactive sound visualization to proactive threshold based RC engine is diagnostic.  
and then is your predictive and prescriptive where you are getting into the marketplace use case idea. That is what I have in my mind and obviously there needs to be mapping in each of this and I really want you to think totally out of the box. I'm giving you more details.  
It's very difficult to put everything in a PRD. We've tried to put what we could, but I hope you're understanding it more, the more we talk about it.

**Vikas Ranga**   13:20  
Yeah, yeah, yeah. No, no, this looks so good. We just need to think around the data barting.  
every at this stage like you know as we don't don't have the real data we have to generate like you know like synthetic data. So we will be using.  
NLM for that and like I just want to ask anything.  
If you have any real data from any client or say you don't have the real data for the property, you have some field names there with you. This is this kind of data, these many fields value there in  
In in in that data, so that will be useful as as well, and it's like, you know, so here the database like a schema will play the key role if we have any real data, just a few names or or some rows of the reveal data and that can.  
Really add value to build it, um, as close as we can build to, like, in, you know, reality.

**Gurtaj Alag**   14:38  
I'll, and again, we'll do it in the right way, because you know, I'll try if we can get, because Lepton is very weak in Telecom, right? They were like some small data set. Let me see, Monday, I've got a call with them.

**Vikas Ranga**   14:51  
Mhm.

**Gurtaj Alag**   14:59  
And I'll see if we can get a data sample from them. US, we don't have anything because you know the problem is it's not that straightforward to get data in the US. So let's see, start with synthetic. I'll probably try and see if there is any other way of getting.  
You know, yesterday I had a meeting with...  
You know, I mentioned earlier, you know, we are a partner to Tata and the Tata team local in Seattle. I met, you know, a key stakeholder and I talked about this MVP and  
Once we have this MVP.  
I, we will show it. I mean, I'm just sorry, I'm deviating, but I'm just connecting the dot. You know, we...

**Vikas Ranga**   15:47  
See.  
S.

**Gurtaj Alag**   15:51  
will show it to Tata and if we are able to.  
you know, get into a POC with Tata and any engagement that they have around the world with us.  
I think the data will come.  
So that is what my plan is. Once we have the MVP, show them the concept and try and see if we can, they can carve out a small POC somewhere and you know, that's when we start actually working with real data. You know, again.  
Will this happen? I don't know. I'm just telling you my train of thought. What I'm trying to, you know, in the first phase, it'll be all synthetic data, unfortunately. It was not very easy to get.

**Vikas Ranga**   16:38  
Okay, sure, sure.

**Gurtaj Alag**   16:42  
You know, this kind of data, but where I'm going with this is if you develop this capability.  
Uh...  
Then...  
I think there is a good chance that we will get an audience for this.  
Platform X marketplace, you know, and I mean, you know, before you go, I literally, I won't even draw it. Satyajeet, can you open up what you made? I want to, I'll tell you like what I mean a little bit. I am just open up what you had created.

**Satyajeet Rout**   17:24  
Yeah, I knew somebody.

**Gurtaj Alag**   17:26  
Okay, because you know like the steps that I was mentioning

**Vikas Ranga**   17:28  
Yeah.

**Gurtaj Alag**   17:31  
Are very important because...  
You know, it should have the...  
The capability to...  
You know, like I said, marketing a category or like say engineering, engineering has got drop call rate. Now I can click on the drop call rate and it'll show a trend. I mean, whatever, like simple visualization, Tableau, Power BI kinds, you know, and then I'm able to put threshold like I was, I'm repeating this thing was, you know.  
It becomes more and more clear how the marketplace, like, you know, bottom to top, like, you know, how do we stack it intelligently, and then comes your RC engine. I should be able to mix and match, correlate a couple things, and that it gives spits out the answer, and then the last part, obviously, which is the most interesting part, is your...  
The SLM agents, I mean, you know, it will be amazing, you know, we have like that agenda, yeah, like I showed separate.  
So a lot of stuff to unpack Vikas, you're a very intelligent person. I know, like, I'm just trying to really paint this picture, you know, in the best way possible. But I know that, but I want you to, you know, basically use your imagination.  
Uh, if the concept is, uh, is our, you know, if you understand what the end goal looks like, basically, you know.  
OK, so look at the Satyajeet that created this. Let me just put it on the big screen, so...  
Like, I mean, he clicked on engineering, just click engineering and then click on site KPI, you know, show some trend, you know, like this is a, I don't like this, I mean, it should be, I mean, these are like some active coming, but do you have like you had some trends also down, go down as an example, no, the the.

**Vikas Ranga**   19:24  
I.

**Gurtaj Alag**   19:35  
Chart you have, I think it's in marketing or somewhere.

**Satyajeet Rout**   19:38  
Yes.

**Gurtaj Alag**   19:42  
Uh, no.

**Satyajeet Rout**   19:44  
See you.

**Gurtaj Alag**   19:46  
Somebody is in retail store. You had like, you know, like a blow up of a pie chart and I don't know where it is.

**Satyajeet Rout**   19:52  
One sec.  
See.  
One sec.

**Gurtaj Alag**   20:07  
So, while Satyajeet is working, so you, you get the point, basically.  
Is one, it's basically just like a regular tool.  
And as you build in the tool, it gets into this marketplace idea. Now that will be very, very interesting for people.

**Satyajeet Rout**   20:19  
Yeah.

**Gurtaj Alag**   20:24  
You know, they they can do the normal stuff, but they have this marketplace to build their own use case, so anyway.

**Satyajeet Rout**   20:31  
Yeah, I pie chart on these.

**Gurtaj Alag**   20:36  
Yeah, like these are, you know, some trends here, and then there's, you know, I mean, it could be anything. I mean, you know, I don't want to, these are, you know, there's an amazing view of regular reporting visualization.

**Satyajeet Rout**   20:36  
Open Signature.  
Play.  
Ohh.  
Yeah.  
Yeah.

**Gurtaj Alag**   20:59  
See, Satyajeet did a good job again.

**Vikas Ranga**   21:02  
Just go.

**Gurtaj Alag**   21:02  
the PRD and some more idea to show what we're trying to do and do the separate review. The last two, the predictive and prescriptive will be the marketplace idea. So like deploy analytic X, like this is the business now here, like you know, they're building the use, I don't know how it would be, but I mean they're building.

**Satyajeet Rout**   21:13  
Yeah.  
Yeah.  
On.

**Gurtaj Alag**   21:24  
They're pulling what are the data sets they want.  
For this use case, I mean, there has to be an area where, okay, pick because we have like hundreds of data possibilities, like which ones do they pick. So I don't know. I mean, because am I confusing more or am I clarifying more? Tell me like.

**Satyajeet Rout**   21:42  
And.

**Vikas Ranga**   21:46  
No, that that's that's fine. I can only need more and more, like, you know, details from your end, the more you share the battery will be.

**Gurtaj Alag**   21:57  
Yeah, and you know.

**Vikas Ranga**   21:57  
Yeah, me, so, so far, so, so, so, so, so good. There's no problem.

**Gurtaj Alag**   22:04  
And I think when we do same in these steps, there are 10 steps. In every step, when you complete a step, okay, I have this view with the data, we review it so that we don't go to the step 2 and realize that step one is not what we wanted. So every step, whatever you break this project into,  
We will definitely make sure that the foundation is being built in the right way. You know, bottom up basically. Anyway, Shruti, back to you. I will keep mum. I hope, you know, yeah.

**Vikas Ranga**   22:26  
Just.

**Shruti Sathe**   22:40  
Yeah, no, I think good discussion. So, Vikas, what do we want to, I don't see a meeting on Monday. I see we have a meeting on Tuesday next week. I think it's every Tuesday, Thursday, I believe.

**Vikas Ranga**   22:50  
Yes.

**Gurtaj Alag**   22:50  
Yeah, yeah.  
Yeah, yeah, I think these are those.

**Shruti Sathe**   22:54  
Yeah, so.

**Vikas Ranga**   22:54  
Yeah, so, so, so then, but other than Tuesday, we can move it on, like, on Monday only, I mean.

**Gurtaj Alag**   23:01  
Okay, Monday, Thursday.

**Vikas Ranga**   23:02  
Better to have, I would like my three days gap rather than just two days.

**Gurtaj Alag**   23:04  
Okay.  
Yeah, Satyajeet tell Kajal to move the Monday and Thursday is what Vikas Singh I agree to Monday and Thursday.

**Vikas Ranga**   23:12  
S.  
S.

**Shruti Sathe**   23:16  
Yeah, will like 1030 work for you on Monday because I think we have some another meeting.

**Satyajeet Rout**   23:17  
Okay.  
Actually, we have a uh, a reference meeting on Monday, so...

**Shruti Sathe**   23:25  
Yeah, that's fine. We can move that. So, but is 10.30 P.m. okay for you for Monday? Vikas, because we can, okay, all right. Yeah, after that we can, we can like move it 30 minutes earlier. That's fine. But yeah, just for Monday, I think we'll have to keep it 10.30 P.m. your time.

**Vikas Ranga**   23:34  
Yeah, yeah, yeah.  
Yeah, yeah, sure.

**Satyajeet Rout**   23:48  
10:30.

**Gurtaj Alag**   23:48  
But because I one more thing, like, okay, this is going to be talked about Platform X. I wanted you to showcase the current tools that you've already created, because what I'm while we go pitch Platform X.  
I want to kind of see if the tools that you're already building, if there is a market for that in the companies I'm going, we are going. So if you could even demo those and the other piece is going to be, you're okay with.

**Vikas Ranga**   24:16  
Got it, got it, got it, got it.

**Gurtaj Alag**   24:28  
I mean, over there is your IP, it doesn't matter, but I will white label it.  
That's the only thing, right?

**Vikas Ranga**   24:33  
Okay, sure, sure. Yeah, sure, sure. Yeah.

**Gurtaj Alag**   24:38  
And if you could show that and one more thing on the mapping, I want to see what all on MapSense have you done. Basically, so we combine, is Neurogen and MapSense, they're two different companies or same companies? I mean, they're the same founders.

**Vikas Ranga**   24:46  
Mhm.  
Yeah, yeah, two, two like companies, different.

**Gurtaj Alag**   24:58  
Yeah.  
Okay, okay.  
Because, so I, I, if you could even bring MapSense into the mix, I mean, those are the...  
Yeah, I mean things that you already have, the use cases you already went, you know, yeah.

**Vikas Ranga**   25:11  
Yeah, yeah, sure, sure, yeah, yeah, sure, sure.

**Gurtaj Alag**   25:14  
So when can you, the reason I say that is a separate conversation, but I wanted to bring it up.

**Vikas Ranga**   25:15  
S.  
Mm-hmm.

**Gurtaj Alag**   25:22  
You know, I've been already socializing. If anybody wants to build something, you know, I I I now know the rate of the plan I'm already talking about. I'm like I said, I I'm treating Neurogent as one unit with TRIDENTX. There's no separation and if we I will create the TRIDENTX APAC IDs very soon when we start engage.

**Vikas Ranga**   25:42  
I.

**Gurtaj Alag**   25:44  
Commercially, when we start get engaging, so that like people see us as one Europe rather than two, you know.

**Vikas Ranga**   25:48  
Yeah, yeah, yeah.

**Gurtaj Alag**   25:50  
And obviously, you know, as we move forward, you know, the joint JV is top on my mind that there is no doubt. I mean, you know, so I think, you know, we are moving in the right direction slowly but steadily, you know.

**Vikas Ranga**   26:07  
Yeah, yeah, yeah, nice, thanks, yeah.

**Gurtaj Alag**   26:08  
Tell me, Vikas, and I'll probably, would you be interested to...  
that we open up a center in Noida.  
And I see that because, you know...  
You already have Gurtaj.  
Could be.  
You don't start.  
Combining, you know, Satyajeet is there. I will onboard another, you know, full stack developer, Vrushali. See, both have Jeet win victory, so I...

**Vikas Ranga**   26:34  
Yeah.

**Gurtaj Alag**   26:47  
I want to see if, like, you know...  
That would be a good one, because the more we start working together, I mean, that's what we try. See, this is like the honeymoon period, basically. I mean, no, sorry, it's even before honeymoon. I mean, we're not married, but you know, it's dating.  
So can we even have, think about it, I don't have to answer it right now, like how do we even bring like Noida presence while we are building this? And I'm talking specifically for telecom. I'm specifically talking about this platform X engagement.

**Vikas Ranga**   27:25  
Yeah, yeah, no, so that's the one thing I think I feel like we should like a focus more on like a sales now and once we have the sales, once we have like like another venue, we all think to grow and in my view, I say this to my team also.  
All the time, the number one thing we should think at first is, like, you know, just the sales. When we have the sales, when we have for the venue, we can do not much, and if the sales are not being there so far, then these are just like our talks.  
So, so I, I feel it in a way, but let's walk jointly now to get the sales and then, like, you know, where we can build what's needed to get the, like, like, sales done, then when we have the sales, then we will need more brains to, like, you know.  
Work and as there will be a lot much work then, and then...

**Gurtaj Alag**   28:32  
Let me rephrase. Okay, that could be the next step. I got it. I'm talking about, like, you know, I really want, I don't want my team not to be aware about what you're building. If you talk about one, I want Satyajeet and Vishwajit to be also.

**Vikas Ranga**   28:44  
Mhm.

**Gurtaj Alag**   28:49  
part of the development team so that they are developing it together. You know, you today with AI, you don't need a lot of people. I'm actually helping you even in the long sense, I mean, we're helping each other. So I want Satyajeet and Vrushali to be part of the development life cycle. I mean.

**Vikas Ranga**   28:51  
Mhm.  
Hmm.  
Mhm.

**Gurtaj Alag**   29:08  
Otherwise, you know, when we talk about like combine, I don't care where they are. They could be in, you could be in Gurung, I'm in Noida, who cares? I mean, I was trying to just suggest my goal is sales.  
For a product, whatever time it takes, you will start seeing a lot of demos. I would rather, the way I benchmark myself, sale is the outcome of how many people you are demoing it to.

**Vikas Ranga**   29:32  
The.  
Yeah, I get it.

**Gurtaj Alag**   29:39  
Right, the right people now, will they will they buy it as soon as they see?

**Vikas Ranga**   29:41  
Yeah, yeah, yeah.

**Gurtaj Alag**   29:44  
At least, I've not seen anybody do that. Maybe, you know, you, you, maybe you have a different experience. My yardstick for me is...

**Vikas Ranga**   29:46  
Yeah, yeah.

**Gurtaj Alag**   29:54  
Shruti and me are demoing to at least one customer every week. I just made, maybe it's two. That is what is going to be the more important part. But while we are doing that, I don't want Satyajeet and Vishwajit to be, you know, just hanging and not, I mean, you saw what Satyajeet has built. I mean, I did it because I wanted to show you.  
you know, basically that, okay, this is what is there in my mind, whichever way we could do it. I mean, obviously there is a limit. So think about it. I want to deploy like, you know, two people ingrained with your, how many people are you putting on this? By the way, it's Mitali along with how many people?

**Vikas Ranga**   30:30  
So, she, she will be the lead and she will loop in like, you know, so, so far we are team size of like in twenty-two and she will like plan it out, whatever she needs from deep learning team, Jenny I team, like in DevOps team or say full full stack and the QA, so, so they...  
Or there's a team, then she she will plan and load them in anywhere she, like, like your needs needs their help, so, so that's how we mostly work with our all, like, like you know, client. There's a one phase from the development side, like you know, so...

**Gurtaj Alag**   30:52  
Okay.

**Vikas Ranga**   31:11  
So that only one can do the entire like a planning there.

**Gurtaj Alag**   31:11  
Yeah.  
I like it. Lovely. That's the right way to do it. I like it. My point is that maybe on Monday when we meet, I want to understand how we can engage Satyajeet and Vishwajit. Also in this team that you're setting, I don't know, one person might be an ex and the other person would be Y.  
That gives a little bit, I won't get closer to the code. See, I'm a technical guy myself. I might not know Python. I told you the only Python I know is in Africa, but I'm able to tame Pythons really well, I can tell you that. So.  
So, and can you...

**Shruti Sathe**   31:57  
I think we, yeah, sorry to interrupt. We have another meeting which is like, yeah, so.

**Gurtaj Alag**   32:00  
Yes.  
Ohh, yes, yes, so yeah, we have to jump off onto this other meeting, but Vikas maybe on Monday think about these things and over the weekend, I'll even call you on certain things, and my my my joke is always to lighten the mood. If I'm joking, that means they are in good shape, you know, so...

**Jang Singh**   32:09  
I can see you.

**Vikas Ranga**   32:10  
Yeah, got it.  
Yeah, yeah, cool, cool. Sounds good.  
Yeah.

**Gurtaj Alag**   32:21  
Alright, take care. Bye, bye, bye, bye, bye.

**Vikas Ranga**   32:22  
Okay. Okay. Bye. Bye. Bye. Thank you. Thanks. Bye.

**Shruti Sathe**   32:22  
Yeah, thank you. Talk to you on Monday.

**Shristi Singh**   32:25  
Bye, everyone.

**Mitali Lakhere**   32:26  
Thank you.

**Vikas Ranga**   32:27  
Bye bye.

**Satyajeet Rout**   32:28  
But...

 stopped transcription