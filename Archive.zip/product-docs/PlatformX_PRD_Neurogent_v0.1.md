# PlatformX — Product Requirements Document (Neurogent draft v0.1)

> **Status:** Draft for discussion — to be reviewed and frozen with the TridentX team.
> **This is a Neurogent.ai working draft**, synthesized from TridentX's shared scope. It does **not** replace TridentX's source docs; it interprets them, commits to a buildable MVP, pushes back where scope exceeds the timeline, and flags open questions for the joint freeze meeting.

---

## 1. Document Control

| Field | Value |
|---|---|
| Product (working name) | **PlatformX** — a telecom data + agentic use-case marketplace |
| Version | 0.1 (draft for discussion) |
| Date | 2026-06-08 |
| Prepared by | Neurogent.ai — Vikas Ranga, Anil Mor (founders); Mitali Lakhere (AI & Dev Lead); Shristi Singh (Growth) |
| For review by | TridentX — Gurtaj Alag (Founder), Shruti Sathe (Product Head), Kajal Yadav (BD), Satyajeet Rout (Fullstack), Karanvir Channi (Cybersecurity), Jang Singh (Delivery) |
| Development owner | Mitali Lakhere + Neurogent team |
| Source documents | `docs/internal_notes.txt`, `docs/Product Requirement Document_PLATFORMX_June 2_2026.docx`, `docs/PLATFORMX_PRD_June 2_2026.xlsx`, `meeting_transcription/meeting_transcription_2_Jun` |
| Status | **Draft → to be frozen** after the joint TridentX discussion |

**How to read this doc:** Sections marked 🟢 are committed MVP. Sections marked 🟡 are deferred/roadmap. Sections marked 🔴 are pushbacks or open questions that need a TridentX decision before freeze.

---

## 2. Executive Summary

TridentX's vision is an **open marketplace/platform** for the telecom industry: a place where many types of telecom data (network/engineering, marketing, customer, third-party crowdsourced, and GIS) are available, and any operator or company can **pick a use-case or problem statement and build their own journey** on top of that data — rather than buying one rigid single-purpose tool.

That full vision is **larger than a 2-week build, and larger than a 4-week build.** Neurogent's mandate (per `internal_notes.txt`) is to push back where (1) scope doesn't make sense, or (2) it can't be delivered in 2 weeks of development.

**Our recommendation — the freeze proposal:**

- **Build one use-case deep, not the marketplace wide.** For the MVP we build **Use-Case 1: the Agentic AI RF Engineer** end-to-end, as a **web app** (conversational agent + KPI/alarm/GIS dashboard), running on **simulated/synthetic telecom data**. This matches Gurtaj's own stated plan in the transcript — *"first we will use air simulation,"* then approach large operators (T-Mobile-class) with the working concept to obtain real data and pilots.
- **Phase everything else.** The generic marketplace, Use-Case 2 (Operator Business Plan), real proprietary-data integrations, third-party feeds, coverage-map scraping, and predictive/prescriptive analytics become a clearly-staged roadmap (§7–§8).
- **The MVP is demoable to "big giants."** Because Gurtaj intends to show the concept to large operators to unlock real data, the MVP optimizes for a **credible, visual, live demo** over breadth.

This document defines that MVP, the roadmap behind it, the market case (§11–§12) for BD conversations, and a numbered list of doubts/pushbacks (§13–§14) to resolve in the freeze meeting.

---

## 3. Product Vision & Strategy

**Long-term vision (TridentX, from the docx + transcript):**
PlatformX is a **marketplace** that aggregates telecom-relevant data across categories — network/engineering, marketing, customer, third-party crowdsource, and GIS/demographic — and gives users the **power to build their own use-case journeys** on top of it. It is explicitly *not* a tool for one XYZ use-case; the example use-cases are showcases of what the platform can do, not the product itself.

**Near-term strategy (Neurogent recommendation):**
A horizontal marketplace with no anchor use-case is hard to sell and hard to build. The fastest path to credibility and to *real operator data* is to **land one sharp, valuable use-case** — the RF Engineer Agent — and use it as the wedge. Each subsequent use-case reuses the same data layer, and the marketplace/“use-case builder” emerges once we have 2–3 proven journeys and real data partners.

**Strategic sequence:**
1. **Wedge** — RF Engineer Agent on simulated data → demoable concept (this MVP).
2. **Land data** — Gurtaj shows the concept to Tier-1 operators → obtain real data + a design partner.
3. **Expand** — second use-case (Operator Business Plan) + real-data connectors on the same data layer.
4. **Platformize** — turn the hardened internals into a self-serve marketplace / use-case builder.

---

## 4. Goals & Success Metrics

**Product goal (from docx):** Create an Agentic AI RF Engineer persona that automates routine RF-engineering tasks (monitoring KPIs, tickets, alarms; identifying underperforming sites/sectors) so engineers spend less time diagnosing and more time troubleshooting — **target: reduce RF engineers' manual daily tasks by ≥25%.**

> 🔴 **Open:** The ≥25% target needs a measurement definition (baseline task list, time study, or task-count proxy). We cannot validate it on simulated data — it becomes a **pilot KPI** with a real design partner. For the MVP we measure *demo* success instead (below).

**MVP success criteria (what "done" means in 2 weeks):**
- A web app where a user can **ask the RF Agent natural-language questions** ("Which sites are underperforming today?", "Summarize the open alarms on site X", "Why is throughput low in sector Y?") and get correct, grounded answers from the simulated dataset.
- A **unified dashboard** showing KPIs + alarms in one view, with trends and a map (GIS) view.
- The agent can **identify underperforming sites/sectors** and **correlate** a KPI dip with related alarms/tickets (reactive + early diagnostic maturity).
- The whole thing runs in a browser and is **stable enough for a live demo** to an external operator.

**Phase-1+ goals (post-MVP):** secure ≥1 operator design partner; ingest ≥1 real data source; validate the ≥25% manual-task-reduction metric in a pilot.

---

## 5. Personas & Client Segments

**Primary user — RF Engineer.** Monitors LTE/5G performance KPIs, tickets, and alarms daily; identifies underperforming sites/sectors; today does this manually across multiple dashboards and vendor tools. Wants faster diagnosis and less swivel-chair work.

**Economic buyer / champion — Operator network-operations leadership** (e.g., Director of RF/Network Ops) and, for the BD motion, **operator executives** Gurtaj engages directly.

**Client segments (sized in §11):**

| Segment | Examples | Why they care |
|---|---|---|
| Tier-1 MNOs | T-Mobile, AT&T, Verizon (US); large global MNOs | Huge networks, large RF teams, high cost of manual ops; can fund pilots |
| Tier-2 / regional & MVNO operators | Regional US carriers, rural operators | Lean teams → automation leverage is high |
| Towercos & neutral-host | Tower companies, DAS/small-cell operators | Site performance & SLA monitoring |
| OSS/NMS & RF-tool vendors | Nokia, Ericsson, Amdocs, RF-planning vendors | Potential channel/embed partners |
| Telecom consultancies & managed-services | Network-ops outsourcers | Deliver the agent as a service to their clients |

> Neurogent recommendation: **target a single Tier-1 or strong regional operator as the first design partner** — that's where Gurtaj's BD relationships and the simulated-data demo point.

---

## 6. 🟢 Scope — MVP (2 Weeks of Development)

**One sentence:** A web app where an **Agentic AI RF Engineer** answers RF-engineering questions and surfaces a unified KPI + alarm + GIS dashboard, all over **simulated telecom data**.

### 6.1 Synthetic data generator
Generates realistic, internally-consistent telecom datasets so the agent and dashboard have something to reason over without any proprietary access:
- **Network inventory:** sites, sectors/cells, lat/long, technology (LTE/5G), band.
- **Performance KPIs / counters:** SINR, RSRP, Throughput, Latency; **Accessibility** (RRC Setup Success Rate, RACH Success Rate, E-RAB Setup Success Rate, Call Setup Success Rate, 5G Registration Success Rate); **Retainability** (Handover Success Rate, Call Drop Rate / DCR, Radio Link Failure Rate); Access Failure Rate (AFR). Time-series over a recent window with a few **injected degradations** (so "underperforming sites" actually exist to find).
- **Alarms:** cell-site alarms tied to sites (severity, type, timestamp).
- **Trouble tickets:** user/site-issue tickets linked to sites/sectors.
- **GIS coordinates:** enough to place sites on a map and color them by health.

### 6.2 Conversational RF Agent (LLM-backed)
- Built on the **latest Claude model** (per environment guidance; exact model id confirmed at build time via the `claude-api` skill).
- Answers RF-engineer questions grounded in the simulated data: identify underperforming sites/sectors, summarize open alarms/tickets for a site, **correlate** a KPI dip with related alarms/tickets, and explain likely cause in plain language.
- Operates at **reactive + early diagnostic** maturity (see §9): "what's wrong and where," with simple correlation — **not** ML prediction or automated action.

### 6.3 Dashboard (web)
- **Unified KPI + alerts view** ("one view" — directly from the xlsx requirement): key KPIs and active alarms together.
- **Trends:** time-series charts for KPIs and alert volumes.
- **GIS / map view:** sites on a map, color-coded by health (the xlsx's "GIS in every module," scoped to one map for MVP).
- Tight loop between dashboard and agent (ask about what you see).

### 6.4 Explicitly inside MVP
Synthetic data; one use-case (RF Agent); chat + dashboard + one map; reactive/early-diagnostic analytics; web delivery; demo-grade stability.

> ✅ **Buildability check:** every MVP item is satisfiable with synthetic data + a web UI + an LLM. Nothing here depends on proprietary or real external data.

---

## 7. 🟡 Scope — Explicitly OUT of MVP (Deferred)

The following are **real, in the vision, and intentionally deferred** — not dropped. Each maps to a roadmap phase (§8):

- **Use-Case 2 — Operator Business Plan** (the docx's second example). → Phase 1.
- **The generic marketplace / use-case builder** (self-serve "pick a problem, build a journey"). → Phase 2.
- **Real proprietary-data integrations:** T-PIM, IMNOS (T-Mobile), Nokia/Ericsson OSS, ATOLL/PLANET/ASSET, operator ticketing tools, UNMS/fault-management. → Phase 1 (gated on data access).
- **Third-party crowdsource feeds:** Ookla, OpenSignal, RootMetrics; coverage-map scraping (e.g., t-mobile.com/coverage); census.gov demographic data. → Phase 1/2 (gated on legal/feasibility — see §14).
- **Marketing & customer-feedback data sets** (market share, churn, demographics, VoC, complaints). → Phase 1/2.
- **Predictive & prescriptive analytics** (ML on historical data; open-loop → closed-loop action→result). → Phase 2.
- **RF *planning actions*** — adjust antenna tilt/azimuth, optimize Tx power, tune handover params, adjust PCI/neighbor lists/frequency, load balancing (the docx "Future Roadmap"). → Phase 2 (these *change the network*; high-risk, post-pilot).

---

## 8. 🟡 Phased Roadmap

| Phase | Theme | Highlights | Data |
|---|---|---|---|
| **Phase 0 — MVP** *(this doc)* | RF Agent wedge | Conversational RF Agent + unified KPI/alarm/GIS dashboard | **Simulated** |
| **Phase 1 — Real data + 2nd use-case** | Prove value with real data | First real-data connector(s); design-partner pilot; validate ≥25% metric; Use-Case 2 (Operator Business Plan); diagnostic correlation hardened | Mix: real + simulated |
| **Phase 2 — Platformize** | Marketplace + advanced analytics | Self-serve use-case builder / data marketplace; predictive (ML) & prescriptive analytics; closed-loop RF planning actions; multi-source data catalog | Real, multi-source |

Timing for Phase 1/2 to be set with TridentX after the MVP demo and first data partner.

---

## 9. Analytics Maturity Model (from the xlsx)

The xlsx defines an analytics ladder; we map each rung to a phase so expectations are explicit:

| Rung | Meaning | Phase |
|---|---|---|
| **Reactive** | Dashboards, current state, trends | 🟢 MVP |
| **Proactive** | Thresholds (with reason), anomaly detection | 🟢 MVP (basic) → 🟡 Phase 1 (full) |
| **Diagnostic** | Correlate signals to find root cause | 🟢 MVP (basic correlation) → 🟡 Phase 1 |
| **Predictive** | Historical data + machine learning to forecast | 🟡 Phase 2 |
| **Prescriptive** | Open-loop → closed-loop (action → result) | 🟡 Phase 2 |

> The MVP deliberately lives at **reactive + basic proactive/diagnostic.** Predictive/prescriptive require historical *real* data and ML — premature on simulated data (see §14).

---

## 10. Data Taxonomy & Sources (from docx + xlsx)

Full taxonomy as TridentX defined it, annotated with MVP treatment. Structure: **Category → Sub-category → KPIs/items → Source.**

| Category | Sub-category | KPIs / items | Source (real) | MVP |
|---|---|---|---|---|
| **Engineering** | Network Performance KPIs | SINR, RSRP, Throughput, Latency | Perf dashboards (PowerBI/Tableau), T-PIM, IMNOS | 🟢 Simulated |
| Engineering | Accessibility KPIs | RRC Setup, RACH, E-RAB Setup, Call Setup, 5G Registration success rates | Operator perf tools | 🟢 Simulated |
| Engineering | Retainability KPIs | Handover Success, DCR, Radio Link Failure, AFR | Operator perf tools | 🟢 Simulated |
| Engineering | Network Parameters | Config audit vs. golden set, non-compliance flags | Vendor OSS (Nokia/Ericsson) | 🟡 Phase 1 |
| Engineering | Network Tickets | Trouble tickets (user/site issues) | Operator ticketing tool | 🟢 Simulated |
| Engineering | Network Alarms | Cell-site alarms | UNMS / vendor OSS | 🟢 Simulated |
| Engineering | Coverage Simulation | Coverage prediction import | ATOLL, PLANET, ASSET; coverage maps | 🟡 Phase 1 |
| Engineering | Field Data | Drive test, walk test, benchmarking | TEMS, Wireless Metrics | 🟡 Phase 1 |
| **Marketing** | — | Market share, churn, customer demographics, retail store performance | Operator marketing tool | 🟡 Phase 1/2 |
| **Customer Feedback** | — | Voice of Customer, complaints/trouble tickets, executive complaints, friendly user trial | Operator care tool | 🟡 Phase 1/2 |
| **Third Party** | Crowdsource | RootMetrics, Ookla, OpenSignal | Public/3rd-party | 🟡 Phase 1 |
| **GIS** | 2D / 2.5D / 3D | Geospatial layers across modules | GIS providers | 🟢 Basic 2D map in MVP; 2.5D/3D later |
| **Planning** | Site/antenna | Site DB, antenna height, azimuth, tilt, power | RF planning tools (ATOLL/PLANET/ASSET) | 🟡 Phase 2 |
| **Misc** | Demographic | Census data | census.gov | 🟡 Phase 1/2 |

---

## 11. Market Opportunity (TAM / SAM / SOM)

> ⚠️ **All figures below are Neurogent estimates with stated assumptions — illustrative, for TridentX to validate before any external use.** We had no market-research source in the shared docs. Numbers are order-of-magnitude and should be replaced with sourced data before fundraising/BD.

**Framing market:** AI/automation for telecom **network operations, OSS/assurance, and RF engineering** — the spend operators put toward monitoring, assurance, and optimizing radio-access networks.

| Metric | Estimate *(assumption — validate)* | Reasoning |
|---|---|---|
| **TAM** | ~**$15–25B/yr** | Global telecom OSS + network-analytics/assurance + RF-planning/optimization software & services spend. Assumes PlatformX can address a slice of OSS/assurance + RF-ops tooling across operators worldwide. |
| **SAM** | ~**$2–4B/yr** | Subset reachable near-term: English-speaking / North America + select global Tier-1/2 operators, focused on RF-ops automation & network-assurance analytics (not full OSS stack). |
| **SOM (3 yr)** | ~**$20–60M/yr** | A focused startup landing a handful of Tier-1/regional accounts at six-/seven-figure ACV. Assumes 1 design partner → ~5–15 paying operators over 3 years. |

**Assumptions to validate with TridentX:** operator count and RF-team sizes in target geos; realistic ACV for an AI RF-ops product; whether we sell to MNOs directly vs. via OSS vendors/consultancies; share of OSS/assurance budget that AI-automation can capture.

**Why now:** 5G densification → more sites/sectors/KPIs per engineer; mature LLM agents can now do real diagnostic reasoning; operators are actively running fast AI MVPs (Gurtaj's T-Mobile anecdote: 2-week MVPs).

---

## 12. Moat / Differentiation

**Where the moat can be real over time:**
- **Domain-specific RF data model + agent.** A telecom-RF-tuned data schema and an agent that genuinely reasons over KPIs/alarms/tickets is hard to replicate generically; correctness in this domain is the differentiator.
- **Multi-source data marketplace + network effects.** If PlatformX becomes the place where telecom data and reusable use-cases live, each new data source and use-case raises switching costs and value for the next customer.
- **Proprietary/real operator data + pilots.** Whoever lands real operator data and proven pilots first builds a data and trust advantage competitors can't easily copy.
- **Workflow embedding & switching costs.** Once the agent is in RF engineers' daily loop, it's sticky.

**Honest assessment — where the moat is thin *today*:**
- On **simulated data alone, there is no moat** — anyone can build a demo. The moat starts when we secure real data and a design partner (Phase 1). This is exactly why the MVP's job is to **unlock that data**, and why Phase 1 matters more than Phase 0 for defensibility.
- The "marketplace" only becomes a moat at scale (multiple data sources + use-cases + customers). Until then it's a roadmap claim, not a defensible asset.

---

## 13. 🔴 Open Questions & Doubts (for the TridentX freeze meeting)

Numbered for line-by-line discussion. Several are TridentX's own questions from the docx/xlsx; the rest are Neurogent's.

**From TridentX's own docs:**
1. **Coverage-map scraping** — the docx asks: *"Will we be able to scrape raw coverage map data from t-mobile.com/coverage and use it?"* → See §14; our view is **don't rely on scraping** for MVP.
2. **OpenSignal from phone** — the docx asks: *"Can you push the OpenSignal data from phone?"* What exactly is intended here — collecting on-device measurements? Clarify the use-case and data-rights.
3. **Intended tech stack** — the xlsx names **Snowflake, "Analytix," "optox."** Are these the mandated data/warehouse stack, or just candidates? (Affects Phase 1 architecture, not MVP.)
4. **"RFBOT"** — the xlsx mentions RFBOT. Is this the intended product name for the RF Engineer Agent, or a separate component?
5. **GIS depth** — xlsx lists 2D / 2.5D / 3D. MVP does basic 2D; confirm when 2.5D/3D is actually needed.

**Neurogent's questions:**
6. **The ≥25% manual-task-reduction metric** — how is it measured, and against what baseline? We propose it becomes a **pilot KPI**, not an MVP gate.
7. **Demo audience & "wow" moment** — which 3–4 questions must the RF Agent nail for Gurtaj's operator demos? We'll tune the synthetic data and agent to those.
8. **First design partner** — which operator (and contact) is the realistic first source of real data? This drives Phase-1 connector priority.
9. **Hosting, security & data residency** — Karanvir's domain: any constraints for the MVP web app (where it's hosted, auth, whether any real/sensitive data ever touches it)?
10. **Branding** — is "PlatformX" the name, or a placeholder? Any TridentX brand to apply to the demo UI?
11. **Who owns synthetic-data realism review?** We'd like a TridentX RF SME (or Karanvir/Satyajeet) to sanity-check the simulated KPIs/alarms so the demo is credible to operators.

---

## 14. 🔴 Pushbacks ("doesn't make sense / not feasible yet")

Each item: **the issue → why → our recommendation.**

1. **Full marketplace in 4 weeks is unrealistic.** A self-serve, multi-data-source, "build any use-case" platform is a multi-quarter effort. → **Build one use-case (RF Agent) deep; phase the marketplace** (§3, §8). This *is* the core pushback in `internal_notes.txt`.
2. **Proprietary-data integrations can't be built without access.** T-PIM, IMNOS, Nokia/Ericsson OSS, ATOLL/PLANET/ASSET, operator ticketing/UNMS are gated behind contracts, credentials, and security review — none obtainable in the MVP window. → **Use simulated data for MVP; connectors begin in Phase 1 once a design partner grants access.** (Aligns with Gurtaj's "air simulation first.")
3. **Scraping coverage maps / pushing OpenSignal data is legally and technically risky.** Public sites' ToS often prohibit scraping; reliability is poor; data rights are unclear. → **Do not depend on scraping for MVP.** Evaluate licensed/API access (Ookla, OpenSignal, RootMetrics) in Phase 1 with legal review.
4. **Predictive / prescriptive analytics and ML are premature.** They need *historical real* data; on synthetic data they'd be theater. → **MVP stays reactive/diagnostic; predictive/prescriptive in Phase 2** (§9).
5. **Closed-loop RF planning actions (tilt/azimuth/power/handover/PCI) are high-risk.** These *change a live network* — safety, approvals, and accountability concerns. → **Strictly Phase 2, behind real pilots and operator sign-off.** Even then, start human-in-the-loop (recommend, don't auto-apply).
6. **The 4-week milestone calendar in `internal_notes.txt` assumes ~2 weeks of dev (Weeks 2–3).** That's only enough for **one focused use-case**, not the broad scope. → This PRD scopes exactly to that 2-week window (§6, §15). Anything beyond is roadmap.

---

## 15. 🟢 Execution Plan (mapped to TridentX's milestones)

From `internal_notes.txt`: Week 1 = finalize PRD & MVP scope; Weeks 2–3 = development; Week 4 = QA & launch. Cadence: **2 calls/week** (e.g., Tue/Thu), organized via Kajal.

| Week | Dates | Focus | Owners |
|---|---|---|---|
| **Week 1** | 8-Jun | **Finalize this PRD & freeze MVP scope** (this meeting). Resolve §13/§14. | Neurogent + TridentX |
| **Week 2** | 15-Jun | Synthetic data generator; data model; agent core (grounded Q&A on KPIs/alarms/tickets); dashboard skeleton (KPI+alarm view). | Mitali + team (Satyajeet support) |
| **Week 3** | 22-Jun | Diagnostic correlation; GIS map view; trends; demo-script tuning; SME realism review of synthetic data; hardening. | Mitali + team; TridentX RF SME |
| **Week 4** | 29-Jun → 4-Jul | **QA & launch.** Bug-fix, demo rehearsal, deploy demo-stable web app. Ready before **7-Jul**. | Neurogent (QA) + Jang (delivery) |

**Definition of done:** §4 MVP success criteria met; live demo runs clean end-to-end on synthetic data.

---

## 16. Risks & Assumptions

| Risk | Impact | Mitigation |
|---|---|---|
| **Synthetic data isn't credible to operators** | Demo falls flat | TridentX RF SME reviews the generated KPIs/alarms in Week 3; inject realistic degradation patterns |
| **LLM gives wrong RF answers** | Trust loss in demo | Ground every answer in the dataset; constrain scope to reactive/diagnostic; test the demo question set hard |
| **No design partner / no real data after demo** | Phase 1 stalls, moat never forms | This is the whole point of the demo — Gurtaj's BD motion must convert; line up the target operator early (§13.8) |
| **Aggressive timeline** | Scope creep breaks the 2-week dev window | Freeze scope this week; treat §7 items as non-negotiable roadmap, not MVP |
| **Market/TAM numbers used externally before validation** | Credibility risk in BD | All figures in §11 are labeled assumptions; replace with sourced data before external use |

**Key assumptions:** MVP runs on synthetic data only; web delivery; latest Claude model for the agent; one use-case; ~2 weeks of real dev capacity (Weeks 2–3); a TridentX SME is available for realism review.

---

## 17. Appendix

**Source documents**
- `docs/internal_notes.txt` — stakeholders, timeline, pushback mandate.
- `docs/Product Requirement Document_PLATFORMX_June 2_2026.docx` — vision, use-cases, data taxonomy, future roadmap.
- `docs/PLATFORMX_PRD_June 2_2026.xlsx` — data-category taxonomy, analytics maturity model, cross-cutting requirements (GIS everywhere, one-view), tech hints.
- `meeting_transcription/meeting_transcription_2_Jun` — marketplace vision, simulated-data-first plan, <7-Jul target, 2-calls/week cadence. *(Note: the transcript has a gap between ~2 min and ~49 min; if a fuller recording exists, sharing it may surface additional scope.)*

**Glossary**
- **LTE / 5G** — 4G / 5G cellular radio technologies.
- **KPI** — Key Performance Indicator.
- **SINR** — Signal-to-Interference-plus-Noise Ratio (signal quality).
- **RSRP** — Reference Signal Received Power (signal strength).
- **RRC** — Radio Resource Control (connection setup).
- **RACH** — Random Access Channel (initial access procedure).
- **E-RAB** — E-UTRAN Radio Access Bearer (data bearer setup).
- **DCR** — Dropped Call Rate.
- **AFR** — Access Failure Rate.
- **Accessibility KPIs** — how reliably users can *connect* (setup success rates).
- **Retainability KPIs** — how reliably connections are *kept* (drop/handover/link-failure rates).
- **OSS** — Operations Support System (vendor network-management software).
- **UNMS** — Unified Network Management System.
- **GIS** — Geographic Information System (geospatial mapping).
- **Towerco** — tower/infrastructure company hosting operator equipment.
- **TAM / SAM / SOM** — Total / Serviceable / Serviceable-Obtainable Market.

---

*Prepared by Neurogent.ai as a discussion draft. Please mark up §13 and §14 directly in the meeting; we will fold decisions in and reissue as v1.0 (frozen).*
