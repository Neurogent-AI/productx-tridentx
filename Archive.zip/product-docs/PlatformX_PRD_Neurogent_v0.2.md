# PlatformX — Product Requirements Document (Neurogent draft v0.2)

> **Status:** Working draft — **MVP scope updated after the Jun-11 TridentX kickoff.**
> **This is a Neurogent.ai working draft.** v0.1 proposed building *one use-case deep* (the RF Engineer Agent) and phasing the marketplace. After two review meetings, **TridentX has redirected the MVP to be the marketplace itself.** This v0.2 supersedes v0.1's core recommendation. v0.1 is retained as a historical record (`PlatformX_PRD_Neurogent_v0.1.md`).

---

## 0. 🔴 v0.2 Change Log — the pivot (read this first)

After showing v0.1 + the RF-Agent prototype, TridentX (Gurtaj, Shruti) decided:

| # | v0.1 said | v0.2 (decided with TridentX) |
|---|---|---|
| 1 | **Build one use-case deep** (RF Engineer Agent); phase the marketplace. | **Build the marketplace itself as the MVP.** "The marketplace is the secret sauce; use-cases are examples on top of it." (Gurtaj, Jun 11) |
| 2 | RF Engineer Agent is the flagship/wedge. | **Operator Business Plan is the flagship example** (it spans engineering + marketing + customer + demographics, so it proves the marketplace isn't engineering-only). **RF Engineer Agent becomes a secondary example.** (Shruti, Jun 11) |
| 3 | MVP = chat + dashboard + one map. | MVP = **data layer across all categories** + the **analytics journey** (reactive → proactive → diagnostic) + a **build-your-own use-case wizard** + **one flagship use-case end-to-end** + RF Agent example, **GIS everywhere.** |
| 4 | Predictive/prescriptive deferred to Phase 2. | **Still deferred** — they are the marketplace's headline ML differentiator but need real data; shown as **locked Phase-2 teasers** in the MVP, realized in the full product. |
| 5 | Cadence Tue/Thu. | **Mon/Thu**; UI/UX frozen on the Monday call. |

Why the pivot (TridentX rationale): a single use-case "falls flat" and locks us into a product; the **marketplace concept** lets a client build *their own* pain-point use-case (Apple/Android-store analogy), which opens a **services / co-build** motion ("you give us the data, the use-case is yours, we build it with you"). Everyone Gurtaj demos to "gets it immediately."

> **How to read this doc:** 🟢 committed MVP · 🟡 deferred/roadmap · 🔴 open question or decision.

---

## 1. Document Control

| Field | Value |
|---|---|
| Product (working name) | **PlatformX** — a telecom **data + agentic use-case marketplace** |
| Version | 0.2 (MVP = marketplace) |
| Date | 2026-06-15 |
| Prepared by | Neurogent.ai — Vikas Ranga, Anil Mor (founders); Mitali Lakhere (AI & Dev Lead); Shristi Singh (Growth) |
| For review by | TridentX — Gurtaj Alag (Founder), Shruti Sathe (Product Head), Kajal Yadav (BD), Satyajeet Rout (Fullstack), Vrushali (Fullstack), Karanvir Channi (Cybersecurity), Jang Singh (Delivery) |
| Development owner | Mitali Lakhere + Neurogent team (≈22; pulled per phase) |
| Source documents | `docs/internal_notes.txt`, `docs/Product Requirement Document_PLATFORMX_June 2_2026.docx`, `docs/PLATFORMX_PRD_June 2_2026.xlsx`, `meeting_transcription/transcription_2_june.docx.md`, `meeting_transcription/transcription_11_june.docx.md` |
| Supersedes | v0.1 (core scope reversed — see §0) |

---

## 2. Executive Summary

PlatformX is a **telecom data + agentic use-case marketplace**: a single pane of glass that aggregates every category of telecom data (engineering/network, marketing, customer, third-party/crowdsource, GIS/demographic) and lets any operator **build its own use-case journey** on top — reporting → alerting → root-cause → (later) predictive/prescriptive — rather than buying a rigid single-purpose tool.

**MVP = the marketplace, demoable on synthetic data.** Per the Jun-11 kickoff, Phase 0 builds the marketplace **wide**: all data categories present (synthetic), the in-product analytics journey (reactive/proactive/diagnostic incl. a **cross-category correlation / RCA engine**), a **build-your-own use-case wizard**, and **one flagship use-case — the Operator Business Plan — built end-to-end**, with the **RF Engineer Agent** as a second example. GIS is a common layer everywhere.

**Why this sells:** Gurtaj will demo the *concept* to "big giants" (an active Tata conversation; a possible small telecom dataset from Lepton) to unlock real data and a POC. The marketplace concept — "even T-Mobile doesn't have a single pane of glass" — plus a **services/co-build** motion is the wedge. Predictive/prescriptive (the ML wow) are shown as locked Phase-2 teasers; they need real historical data to be honest.

This document defines that marketplace MVP (§6), the phased roadmap (§8), the analytics journey (§9), the data taxonomy (§10), market/moat (§11–§12), and the updated open questions & resolved pushbacks (§13–§14).

---

## 3. Product Vision & Strategy

**Vision.** PlatformX is the place where telecom data lives and where users compose AI-enabled use-cases on it. Telecom first (operators, then towercos, MVNOs), then adjacent verticals that share the same data shape — **data centers, fiber, satellite, CSP, Wi-Fi** (Jun-2). Not a tool for one XYZ use-case; example use-cases are showcases of what the platform can do.

**Strategic sequence (revised):**
1. **MVP — the marketplace** on synthetic data: data layer + analytics journey + wizard + **Business Plan** flagship + RF Agent example. *(this doc)*
2. **Land data** — Gurtaj demos the concept (Tata / Lepton / Tier-1) → small POC → first real data.
3. **Real data + more use-cases + predictive** — connectors live; harden RCA; add use-cases; introduce validated predictive.
4. **Prescriptive + scale** — closed-loop (action→result); multi-vertical; the **services / co-build** engine (build clients' use-cases with them).

**Business model angle (Gurtaj).** Platform + **services**: the platform is the fabric; revenue comes from co-building each client's use-case from their pain point and data. White-labelable. Neurogent's **MapSense** provides the GIS/mapping depth.

---

## 4. Goals & Success Metrics

**Product goal.** Give telecom teams a single, AI-enabled marketplace to turn fragmented data into decisions — from a weekly exec report to an agentic use-case — without stitching tools together.

**MVP success criteria ("done" for the demo):**
- A user can browse **all data categories** (synthetic) and open any sub-category KPI to a **trend** (reactive).
- A user can set a **threshold** on a KPI and see an **alert** preview (proactive).
- A user can run the **correlation / RCA engine** across categories — e.g. *market share ↓ correlates with drop-call ↑* — and get a grounded, plain-language explanation (diagnostic).
- A user can run the **build-your-own use-case wizard** end-to-end (predictive/prescriptive shown locked).
- The **Operator Business Plan** flagship use-case works end-to-end; the **RF Engineer Agent** example is openable.
- **GIS** is present across modules; the whole thing runs in a browser and is stable for a live demo to operators.

> 🔴 The v0.1 **≥25% manual-task-reduction** target now belongs to the *RF Engineer use-case* and becomes a **pilot KPI** with a real design partner — not an MVP gate. MVP success is *demo* success (above).

**Phase-1+ goals:** ≥1 real data source (Tata/Lepton/Tier-1 POC); 2nd–3rd use-cases; validated predictive.

---

## 5. Personas & Client Segments

The marketplace serves **three** personas (vs. v0.1's single RF engineer):

- **Operator leadership / executive (primary buyer for the flagship).** Wants the *business plan*: where market share is leaking, whether it's network- or sales-driven, where to invest. Buys the single-pane + cross-data correlation.
- **The builder / analyst.** Composes use-cases in the wizard (reporting → alerting → RCA), no/low-code (Salesforce-style), for their own pain point.
- **RF / network engineer (secondary use-case user).** The RF Engineer Agent — daily KPI/alarm/ticket triage and root-cause.

**Client segments:** Tier-1 MNOs (T-Mobile/AT&T/Verizon); Tier-2/regional & MVNOs; towercos/neutral-host; OSS/NMS & RF-tool vendors (channel); telecom consultancies/managed-services. **Adjacent (Phase 2):** data-center, fiber, satellite, CSP, Wi-Fi operators (same data shape).

---

## 6. 🟢 Scope — MVP (the Marketplace)

**One sentence:** A web marketplace where a user browses all telecom data categories (synthetic), explores them through the reactive→proactive→diagnostic journey (incl. a cross-category RCA engine), composes use-cases in a wizard, and opens a flagship **Business Plan** use-case end-to-end (plus an **RF Engineer Agent** example) — GIS everywhere.

### 6.1 Data Layer (all categories, synthetic)
Single pane of glass. Categories with sub-categories/KPIs as synthetic, internally-consistent time-series: **Engineering** (SINR, RSRP, throughput, latency, accessibility & retainability KPIs, alarms, tickets), **Marketing** (market share, churn, ARPU, demographics), **Customer Feedback** (VoC/CSAT, complaints), **Third-Party** (Ookla/OpenSignal/RootMetrics-style), **GIS** (2D), **Planning** / **Misc** (catalogued). Each category carries an **AI connector** concept (ingest/transform). Real connectors are catalogued but gated (§7).

### 6.2 Analytics journey (in-product)
- **Reactive** — pick a KPI → trend visualization (line/bar/pie).
- **Proactive** — set a threshold → alert preview when breached.
- **Diagnostic** — **correlation / RCA engine**: select 2+ signals *across categories* → correlation result + grounded AI explanation (Gurtaj's example: market-share drop ↔ drop-call rise → network-driven churn).

### 6.3 Build-your-own use-case wizard
Compose a journey: pick data → choose stage(s) (reactive/proactive/diagnostic) → compose views (dashboard/map/agent/report) → configure agent → publish to the gallery. **Predictive & prescriptive are shown as locked "Full product / Phase 2"** rungs.

### 6.4 Flagship use-case — Operator Business Plan (end-to-end)
Multi-data: market share, churn, ARPU, demographics, network experience + GIS **densification map**; a **Business-Planning agent** ("where should we densify?", "which markets are at churn risk?"). This is the lead demo.

### 6.5 Secondary example — RF Engineer Agent
The v0.1 RF console, folded in as a use-case workspace (KPI/alarm/GIS + agent). Also preserved standalone (`mvp-rf-legacy/`).

### 6.6 Cross-cutting
GIS everywhere; an **omni-agent** that answers across data domains (RF + business), grounded with source citations; persistent **"Simulated data"** badge.

> ✅ **Buildability:** everything is satisfiable with synthetic data + a web UI + an LLM. Nothing depends on real/proprietary data.

---

## 7. 🟡 Scope — OUT of MVP (Deferred, in the full product)

- **Validated predictive & prescriptive analytics** (forecasts; closed-loop action→result) — need real historical data; shown as locked teasers in MVP, realized in the full-product prototype/Phase 2.
- **Real proprietary-data connectors:** T-PIM, IMNOS, Nokia/Ericsson OSS, ATOLL/PLANET/ASSET, operator ticketing, UNMS — gated on access (Tata/Lepton/Tier-1).
- **Third-party crowdsource feeds** (Ookla/OpenSignal/RootMetrics) & **coverage-map scraping** — licensing/legal (see §14).
- **Closed-loop RF planning actions** (tilt/azimuth/power/handover/PCI) — high-risk, change a live network.
- **Multi-vertical** beyond telecom (data center/fiber/satellite); **deep governance**; **services/co-build** tooling at scale; **MapSense** 2.5D/3D GIS.

---

## 8. 🟡 Phased Roadmap

| Phase | Theme | Highlights | Data |
|---|---|---|---|
| **Phase 0 — Marketplace MVP** *(this doc)* | The fabric | Data layer (all categories) · reactive/proactive/diagnostic + RCA engine · build-your-own wizard · **Business Plan** flagship · RF Agent example · GIS | **Simulated** |
| **Phase 1 — Real data + more use-cases** | Prove value | First real connector(s) via POC; harden RCA; 2nd–3rd use-cases; **validated predictive** | Mix |
| **Phase 2 — Prescriptive + scale** | Differentiate | Prescriptive / closed-loop (action→result); multi-vertical; **services/co-build** engine; MapSense GIS depth | Real, multi-source |

---

## 9. Analytics Maturity Model (the marketplace journey)

| Rung | Meaning | Status |
|---|---|---|
| **Reactive** | Reporting, trends, current state | 🟢 MVP (interactive) |
| **Proactive** | Thresholds + alerts, anomaly | 🟢 MVP (interactive) |
| **Diagnostic** | Correlate signals → root cause (RCA engine) | 🟢 MVP (interactive, cross-category) |
| **Predictive** | Historical data + ML to forecast | 🟡 Full product / Phase 1–2 (locked in MVP) |
| **Prescriptive** | Open-loop → closed-loop (action → result) | 🟡 Full product / Phase 2 (locked in MVP) |

> The marketplace **wizard** exposes all five rungs so the *concept* lands, but predictive/prescriptive are **locked** in the MVP — on synthetic data they'd be theatre (§14.4). They are fully realized in the full-product prototype.

---

## 10. Data Taxonomy & Sources

Structure: **Category → Sub-category → KPIs/items → Source.** MVP treatment: 🟢 synthetic & in the marketplace now; 🟡 catalogued but gated.

| Category | Sub-category | KPIs / items | Source (real) | MVP |
|---|---|---|---|---|
| **Engineering** | Performance KPIs | SINR, RSRP, Throughput, Latency | Perf dashboards, T-PIM, IMNOS | 🟢 Simulated |
| Engineering | Accessibility | RRC, RACH, E-RAB, Call-Setup, 5G-Reg success | Operator perf tools | 🟢 Simulated |
| Engineering | Retainability | Handover, DCR, RLF, AFR | Operator perf tools | 🟢 Simulated |
| Engineering | Alarms / Tickets | Cell-site alarms; trouble tickets | UNMS / ticketing | 🟢 Simulated |
| Engineering | Parameters / Coverage / Field | Config audit; ATOLL/PLANET; drive/walk test | Vendor OSS; RF tools; TEMS | 🟡 Catalogued |
| **Marketing** | — | Market share, churn, ARPU, demographics, retail | Operator marketing tool | 🟢 Simulated (NEW in MVP) |
| **Customer Feedback** | — | VoC/CSAT, complaints, exec complaints | Operator care tool | 🟢 Simulated (NEW in MVP) |
| **Third Party** | Crowdsource | Ookla, OpenSignal, RootMetrics | Licensed/3rd-party | 🟢 Simulated · 🟡 real gated |
| **GIS** | 2D / 2.5D / 3D | Geospatial layers (everywhere) | GIS / MapSense | 🟢 2D in MVP; 2.5D/3D later |
| **Planning** | Site/antenna | Site DB, height, azimuth, tilt, power | RF planning tools | 🟡 Catalogued |
| **Misc** | Demographic | Census | census.gov | 🟢 Simulated · 🟡 real gated |

---

## 11. Market Opportunity (TAM / SAM / SOM)

> ⚠️ **Neurogent estimates with stated assumptions — illustrative, validate before external use.**

**Framing:** broader than v0.1 — a **multi-category telecom data + analytics + agentic-automation platform** (network assurance/OSS + marketing/BI + customer experience), expandable to adjacent verticals.

| Metric | Estimate *(assumption — validate)* | Reasoning |
|---|---|---|
| **TAM** | ~**$25–40B/yr** | Telecom OSS/assurance + analytics/BI + customer-experience tooling globally; marketplace can address a slice across categories. |
| **SAM** | ~**$3–6B/yr** | North America + select global Tier-1/2 operators; data-marketplace + use-case automation. |
| **SOM (3 yr)** | ~**$25–75M/yr** | Land 1 design partner → handful of operators at six-/seven-figure ACV + services. |

**Why now:** 5G densification → data sprawl; LLM agents can reason + correlate; operators run fast AI MVPs; nobody offers a true single pane of glass + build-your-own use-case.

---

## 12. Moat / Differentiation

- **Single pane of glass across all telecom data categories** — genuinely rare ("even T-Mobile doesn't have it"). Aggregation + the cross-category RCA engine is the near-term differentiator.
- **Build-your-own use-case marketplace + network effects** — each new data source and reusable use-case raises value/switching cost.
- **Services / co-build motion** — building the client's use-case from their data and pain point is sticky and hard to copy.
- **Real operator data + pilots** — first to land real data wins a trust/data advantage.
- **MapSense GIS depth** — geospatial as a cross-cutting strength.

**Honest assessment:** on synthetic data there's no moat yet — the MVP's job is to **sell the concept and unlock real data**. Predictive/prescriptive are claims until validated on real data.

---

## 13. 🔴 Open Questions & Doubts

**Carried from v0.1 (still open):** coverage-map scraping (don't rely on it); OpenSignal-from-phone intent; mandated stack (Snowflake/"Analytix"/"optox"); GIS depth (2.5D/3D timing); hosting/security/data-residency (Karanvir); branding ("PlatformX" final?); synthetic-data realism review by a TridentX SME.

**New from Jun-11:**
1. **Real data via Tata/Lepton** — Lepton is "weak in telecom" (small set); Tata POC is the bigger bet. Which lands first, and what fields/rows can we get to shape the schema? (Even field names + a few rows materially improve realism.)
2. **Flagship confirmation** — Business Plan is the lead example; confirm the exact exec questions it must nail for demos.
3. **White-labelling** — TridentX wants to white-label Neurogent's existing tools; which, and brand rules?
4. **MapSense integration** — how deep for the MVP GIS (2D now; 2.5D/3D later)?
5. **Joint dev team** — Satyajeet & Vrushali embedded with Neurogent; Noida presence — scope later (sales first, per Vikas).
6. **Verticals** — order beyond telecom (data center/fiber/satellite)?

---

## 14. 🔴 Pushbacks — status

1. **"Full marketplace in 4 weeks is unrealistic"** *(v0.1 pushback)* → **RESOLVED / REVERSED by TridentX.** Client chose marketplace-first: a single use-case "falls flat" and the marketplace concept + services angle is what sells. **v0.2 scopes a demo-grade marketplace on synthetic data** (breadth via synthetic + one flagship use-case deep), buildable in the window. The depth-vs-breadth trade is managed by: synthetic data everywhere, reactive/proactive/diagnostic only, predictive/prescriptive locked, one flagship use-case end-to-end.
2. **Proprietary-data integrations need access** → unchanged: **synthetic for MVP; connectors begin at POC** (Tata/Lepton).
3. **Scraping coverage maps / OpenSignal-from-phone is risky** → unchanged: **don't depend on scraping;** evaluate licensed APIs in Phase 1.
4. **Predictive/prescriptive are premature on synthetic data** → **refined:** the marketplace *wizard shows* all five rungs (concept), but predictive/prescriptive are **locked in the MVP** and only **realized in the full product / with real data**. Avoids theatre while still demoing the vision.
5. **Closed-loop network actions are high-risk** → unchanged: **strictly Phase 2**, human-in-the-loop first.

---

## 15. 🟢 Execution Plan

Cadence updated to **Monday + Thursday** (org. via Kajal). UI/UX reviewed/frozen on the Monday call. Target: demo-ready **before 7-Jul**.

| Week | Dates | Focus | Owners |
|---|---|---|---|
| **Week 1** | 8-Jun → 15-Jun | Reframe PRD to marketplace MVP (this v0.2); **UI/UX of the marketplace** shared for feedback; freeze scope/UX. | Neurogent + TridentX |
| **Week 2** | 15-Jun | Synthetic data across all categories; data-layer + reactive/proactive/diagnostic (RCA engine); marketplace shell + wizard skeleton. | Mitali + team (Satyajeet/Vrushali) |
| **Week 3** | 22-Jun | Flagship **Business Plan** use-case end-to-end; RF Agent example; GIS; wizard publish; omni-agent; SME realism review; hardening. | Mitali + team; TridentX SME |
| **Week 4** | 29-Jun → 4-Jul | **QA & launch.** Demo rehearsal; deploy demo-stable marketplace. | Neurogent (QA) + Jang (delivery) |

**Deliverables:** (a) **Marketplace MVP** prototype; (b) **Full-product** prototype (predictive/prescriptive unlocked, connectors live, multi-vertical, services); (c) preserved standalone **RF console**; (d) this PRD v0.2.
**Definition of done:** §4 MVP success criteria met; live demo runs clean end-to-end on synthetic data.

---

## 16. Risks & Assumptions

| Risk | Impact | Mitigation |
|---|---|---|
| **Marketplace breadth vs. timeline** | Scope creep breaks the window | Synthetic data everywhere; **one** flagship use-case deep; reactive/proactive/diagnostic only; predictive/prescriptive locked |
| **Synthetic data not credible** | Demo falls flat | TridentX SME realism review; inject realistic correlated degradations (e.g., churn↔drop-call) |
| **Predictive/prescriptive over-promise** | Trust risk | Clearly **locked + "Phase 2 / needs real data"** in the MVP |
| **No real data after demo** | Phase 1 stalls | The demo's job is to unlock Tata/Lepton/Tier-1 data; line up POC early |
| **Marketplace wizard feels like vaporware** | Credibility | Make the wizard *actually compose & publish* a working journey on synthetic data |
| **TAM numbers used externally pre-validation** | BD credibility | All §11 figures labelled assumptions |

**Key assumptions:** synthetic data only for MVP; web delivery; latest **Claude** model for agents; one flagship use-case end-to-end; ~2 weeks real dev (Weeks 2–3); TridentX SME available.

---

## 17. Appendix

**Source documents**
- `docs/internal_notes.txt` — stakeholders, timeline, pushback mandate.
- `docs/Product Requirement Document_PLATFORMX_June 2_2026.docx` — vision, use-cases, data taxonomy, roadmap.
- `docs/PLATFORMX_PRD_June 2_2026.xlsx` — data taxonomy, analytics maturity, GIS-everywhere/one-view, tech hints (Snowflake, Analytix, OptoX, RFBOT).
- `meeting_transcription/transcription_2_june.docx.md` — marketplace vision, 3 dimensions (data / journey / wizard), single-pane, build-your-own (Apple/Android-store analogy), services angle.
- `meeting_transcription/transcription_11_june.docx.md` — **the pivot**: build the whole marketplace as MVP; Business Plan flagship; synthetic first; Tata/Lepton data; Mon/Thu cadence; white-label; MapSense; joint team.

**Glossary** — *LTE/5G, KPI, SINR, RSRP, RRC, RACH, E-RAB, DCR, AFR, Accessibility/Retainability KPIs, OSS, UNMS, GIS, Towerco, ARPU, RCA (root-cause analysis), TAM/SAM/SOM.* (Definitions as in v0.1 §17.)

---

*Prepared by Neurogent.ai. v0.2 reflects the marketplace-first MVP agreed with TridentX on Jun-11. Mark up §13/§14 directly; we will fold decisions in and reissue as v1.0 (frozen).*
